package com.andrei1058.bedwars.api.util;

import com.andrei1058.bedwars.api.BedWars;
import com.andrei1058.bedwars.api.arena.IArena;
import com.andrei1058.bedwars.api.configuration.ConfigPath;
import com.andrei1058.bedwars.api.server.VersionSupport;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.util.Vector;
import org.jetbrains.annotations.NotNull;

import java.util.LinkedList;
import java.util.concurrent.atomic.AtomicInteger;

public class BlastProtectionUtil {

    private final VersionSupport versionSupport;
    private final BedWars api;

    public BlastProtectionUtil(VersionSupport versionSupport, BedWars api) {
        this.versionSupport = versionSupport;
        this.api = api;
    }


    /**
     * Check if block is protected by blast-proof glass or an unbreakable block from a point of view
     * <p>
     * if pov is null, block is checked by {@link VersionSupport#isGlass(Material)} and {@link IArena#isBlockPlaced(Block)} instead.
     * Otherwise, a ray tracing is performed to check whether there is any glass block or an unbreakable block.
     * <p>
     * If arena is null, then glass only be checked.
     *
     * @param arena Arena instance.
     * @param pov   the point of view.
     * @param block the block instance.
     * @param step  how frequent to check the ray (0.25 - 0.5 recommended).
     * @return whether there's unbreakable block between the pov and the block
     */
    public boolean isProtected(@NotNull IArena arena, Location pov, @NotNull Block block, double step) {

        if (arena.isProtected(block.getLocation()) || arena.isTeamBed(block.getLocation())) {
            return true;
        }

        boolean rayBlockedByGlass = api.getConfigs().getMainConfig().getBoolean(ConfigPath.GENERAL_TNT_RAY_BLOCKED_BY_GLASS);

        // TPS 优化（烈焰弹炸大量可挖掘方块卡顿修复）：
        // 1) 快速路径 —— 目标方块是玩家放置的（或地图允许破坏），且其 3x3 水平范围内
        //    没有原地图方块 / 玻璃阻挡时，直接判定不保护，跳过昂贵的射线追踪。
        //    玩家建造区内部的大片方块绝大多数走这条路径，可省掉每方块数十次方块访问。
        if (arena.isAllowMapBreak() || arena.isBlockPlaced(block)) {
            boolean nearProtected = false;
            for (int dx = -1; dx <= 1 && !nearProtected; dx++) {
                for (int dz = -1; dz <= 1 && !nearProtected; dz++) {
                    Block nb = block.getRelative(dx, 0, dz);
                    if (nb.getType() == Material.AIR) continue;
                    if (arena.isProtected(nb.getLocation()) || arena.isTeamBed(nb.getLocation())) {
                        nearProtected = true;
                        break;
                    }
                    if (versionSupport.isGlass(nb.getType())) {
                        nearProtected = true;
                        break;
                    }
                    if (!arena.isBlockPlaced(nb) && !arena.isAllowMapBreak()) {
                        nearProtected = true;
                        break;
                    }
                }
            }
            if (!nearProtected) {
                return false;
            }
        }

        // Trace blocks from pov to the block location
        final Location target = block.getLocation();

        LinkedList<Vector> targetVectors = new LinkedList<>();

        // 性能优化：9 条射线（中心+8角）、0.75 步长 → 5 条射线（中心+上下左右）、1.0 步长，
        // 保持保护判定逻辑，进一步降低爆炸波及大片方块时的方块访问次数。
        double alteredRayStep = 0.75;
        // 中心射线
        targetVectors.add(pov.clone().toVector().toBlockVector());
        // 4 条十字射线
        for (double XrayRadius : new double[]{alteredRayStep * -1, alteredRayStep}) {
            targetVectors.add(pov.clone().toVector().toBlockVector().add(new Vector(XrayRadius, 0, 0)));
        }
        for (double ZrayRadius : new double[]{alteredRayStep * -1, alteredRayStep}) {
            targetVectors.add(pov.clone().toVector().toBlockVector().add(new Vector(0, 0, ZrayRadius)));
        }

        AtomicInteger protectedTimes = new AtomicInteger();
        int totalRays = targetVectors.size();

        targetVectors.forEach(targetVector -> {
            BlockRay ray;
            try {
                ray = new BlockRay(block.getWorld(), targetVector, target.toVector(), step);
            } catch (IllegalArgumentException ignored) {
                return;
            }

            while (ray.hasNext()) {
                Block nextBlock = ray.next();

                if (nextBlock.getType() == Material.AIR) {
                    continue;
                }

                if (rayBlockedByGlass && versionSupport.isGlass(nextBlock.getType())) {
                    // If a block is a glass
                    protectedTimes.getAndIncrement();
                    return;
                }

                if (!arena.isBlockPlaced(nextBlock) && !arena.isAllowMapBreak()) {
                    protectedTimes.getAndIncrement();
                    return;
                }
            }
        });

        return totalRays - protectedTimes.get() < 3;
    }
}
