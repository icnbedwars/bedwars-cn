package com.andrei1058.bedwars.support.version.v1_21_11;

import com.andrei1058.bedwars.api.arena.IArena;
import com.andrei1058.bedwars.support.version.v1_20_R4.v1_20_R4;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.command.Command;
import org.bukkit.command.SimpleCommandMap;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Fireball;
import org.bukkit.entity.Player;
import org.bukkit.entity.TNTPrimed;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.plugin.Plugin;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.util.Vector;

import java.lang.reflect.Method;
import java.util.EnumMap;
import java.util.Map;

/**
 * Version support adapter for Minecraft 1.21.11.
 * <p>
 * The modern Paper runtime changed several internal APIs (command map lookup,
 * equipment packets, item tag storage, block blast resistance mapping).
 * This adapter re-implements those methods using the stable Bukkit/Paper API
 * and inherits the remaining behaviour from {@link v1_20_R4}.
 * <p>
 * IMPORTANT: the v1_20_R3/v1_20_R4 chain relies on obfuscated NMS classes
 * (CraftItemStack, CraftPlayer, PacketPlayOut*) that do NOT exist on 1.21.11.
 * Any method in that chain that touches NMS must be overridden here with a
 * pure Bukkit/Paper implementation, otherwise a NoClassDefFoundError is thrown
 * at the exact moment the game path calls it (join, game start, generator
 * rotation, player move, shop upgrades).
 */
@SuppressWarnings("unused")
public class v1_21_11 extends v1_20_R4 {

    public v1_21_11(Plugin plugin, String name) {
        super(plugin, name);
    }

    @Override
    public void registerCommand(String name, Command clasa) {
        try {
            Object server = Bukkit.getServer();
            Method getCommandMap = server.getClass().getMethod("getCommandMap");
            SimpleCommandMap commandMap = (SimpleCommandMap) getCommandMap.invoke(server);
            commandMap.register(name, clasa);
        } catch (Exception ex) {
            throw new RuntimeException("Failed to register command '" + name + "'", ex);
        }
    }

    @Override
    public boolean isBukkitCommandRegistered(String command) {
        try {
            Object server = Bukkit.getServer();
            Method getCommandMap = server.getClass().getMethod("getCommandMap");
            SimpleCommandMap commandMap = (SimpleCommandMap) getCommandMap.invoke(server);
            return commandMap.getCommand(command) != null;
        } catch (Exception ex) {
            return false;
        }
    }

    @Override
    public ItemStack addCustomData(ItemStack i, String data) {
        return setTag(i, PLUGIN_TAG_GENERIC_KEY, data);
    }

    @Override
    public ItemStack setTag(ItemStack itemStack, String key, String value) {
        if (itemStack == null || key == null || key.isEmpty()) {
            return itemStack;
        }
        ItemMeta meta = itemStack.getItemMeta();
        if (meta == null) {
            return itemStack;
        }
        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        NamespacedKey namespacedKey = new NamespacedKey(getPlugin(), key.toLowerCase());
        if (value == null) {
            pdc.remove(namespacedKey);
        } else {
            pdc.set(namespacedKey, PersistentDataType.STRING, value);
        }
        itemStack.setItemMeta(meta);
        return itemStack;
    }

    @Override
    public String getTag(ItemStack itemStack, String key) {
        if (itemStack == null || key == null || key.isEmpty()) {
            return null;
        }
        ItemMeta meta = itemStack.getItemMeta();
        if (meta == null) {
            return null;
        }
        return meta.getPersistentDataContainer().get(new NamespacedKey(getPlugin(), key.toLowerCase()), PersistentDataType.STRING);
    }

    @Override
    public boolean isCustomBedWarsItem(ItemStack i) {
        return getCustomData(i) != null;
    }

    @Override
    public String getCustomData(ItemStack i) {
        return getTag(i, PLUGIN_TAG_GENERIC_KEY);
    }

    @Override
    public void registerTntWhitelist(float endStoneBlast, float glassBlast) {
        // 1.21.11 mapping changed; legacy reflective field access from v1_20_R3 is unsafe.
        // Keep startup stable and rely on default block blast resistance behavior.
    }

    @Override
    public void setSource(TNTPrimed tnt, Player owner) {
        try {
            tnt.setSource(owner);
        } catch (Throwable ignored) {
            // Best-effort only.
        }
    }

    @Override
    public Fireball setFireballDirection(Fireball fireball, Vector vector) {
        fireball.setDirection(vector);
        return fireball;
    }

    @Override
    public void hideArmor(Player victim, Player receiver) {
        try {
            Map<EquipmentSlot, ItemStack> hidden = new EnumMap<>(EquipmentSlot.class);
            ItemStack air = new ItemStack(Material.AIR);
            hidden.put(EquipmentSlot.HEAD, air);
            hidden.put(EquipmentSlot.CHEST, air);
            hidden.put(EquipmentSlot.LEGS, air);
            hidden.put(EquipmentSlot.FEET, air);
            hidden.put(EquipmentSlot.HAND, air);
            hidden.put(EquipmentSlot.OFF_HAND, air);
            receiver.sendEquipmentChange(victim, hidden);
        } catch (Throwable ignored) {
            // Best-effort only.
        }
    }

    @Override
    public void showArmor(Player victim, Player receiver) {
        try {
            Map<EquipmentSlot, ItemStack> visible = new EnumMap<>(EquipmentSlot.class);
            visible.put(EquipmentSlot.HEAD, safeItem(victim.getInventory().getHelmet()));
            visible.put(EquipmentSlot.CHEST, safeItem(victim.getInventory().getChestplate()));
            visible.put(EquipmentSlot.LEGS, safeItem(victim.getInventory().getLeggings()));
            visible.put(EquipmentSlot.FEET, safeItem(victim.getInventory().getBoots()));
            visible.put(EquipmentSlot.HAND, safeItem(victim.getInventory().getItemInMainHand()));
            visible.put(EquipmentSlot.OFF_HAND, safeItem(victim.getInventory().getItemInOffHand()));
            receiver.sendEquipmentChange(victim, visible);
        } catch (Throwable ignored) {
            // Best-effort only.
        }
    }

    @Override
    public void sendPlayerSpawnPackets(Player p, IArena arena) {
        if (arena == null) {
            return;
        }
        for (Player other : arena.getPlayers()) {
            if (!other.equals(p)) {
                p.hidePlayer(getPlugin(), other);
                p.showPlayer(getPlugin(), other);
            }
        }
        for (Player other : arena.getSpectators()) {
            if (!other.equals(p)) {
                p.hidePlayer(getPlugin(), other);
                p.showPlayer(getPlugin(), other);
            }
        }
    }

    private ItemStack safeItem(ItemStack item) {
        return item == null ? new ItemStack(Material.AIR) : item;
    }

    // ------------------------------------------------------------------
    // Pure Bukkit/Paper overrides for methods whose v1_20_R3/v1_20_R4
    // implementation touches NMS classes that do not exist on 1.21.11.
    // Without these, NoClassDefFoundError is thrown on: join (player
    // heads), game start (sword check, generator holograms), player move
    // (hologram update), shop upgrade tiers, void kills, redstone dots.
    // ------------------------------------------------------------------

    @Override
    public boolean isArmor(ItemStack itemStack) {
        if (itemStack == null) return false;
        switch (itemStack.getType()) {
            case LEATHER_HELMET:
            case LEATHER_CHESTPLATE:
            case LEATHER_LEGGINGS:
            case LEATHER_BOOTS:
            case CHAINMAIL_HELMET:
            case CHAINMAIL_CHESTPLATE:
            case CHAINMAIL_LEGGINGS:
            case CHAINMAIL_BOOTS:
            case IRON_HELMET:
            case IRON_CHESTPLATE:
            case IRON_LEGGINGS:
            case IRON_BOOTS:
            case GOLDEN_HELMET:
            case GOLDEN_CHESTPLATE:
            case GOLDEN_LEGGINGS:
            case GOLDEN_BOOTS:
            case DIAMOND_HELMET:
            case DIAMOND_CHESTPLATE:
            case DIAMOND_LEGGINGS:
            case DIAMOND_BOOTS:
            case NETHERITE_HELMET:
            case NETHERITE_CHESTPLATE:
            case NETHERITE_LEGGINGS:
            case NETHERITE_BOOTS:
            case ELYTRA:
                return true;
            default:
                return false;
        }
    }

    @Override
    public boolean isTool(ItemStack itemStack) {
        if (itemStack == null) return false;
        switch (itemStack.getType()) {
            case WOODEN_PICKAXE:
            case STONE_PICKAXE:
            case IRON_PICKAXE:
            case GOLDEN_PICKAXE:
            case DIAMOND_PICKAXE:
            case NETHERITE_PICKAXE:
            case WOODEN_SHOVEL:
            case STONE_SHOVEL:
            case IRON_SHOVEL:
            case GOLDEN_SHOVEL:
            case DIAMOND_SHOVEL:
            case NETHERITE_SHOVEL:
            case WOODEN_HOE:
            case STONE_HOE:
            case IRON_HOE:
            case GOLDEN_HOE:
            case DIAMOND_HOE:
            case NETHERITE_HOE:
                return true;
            default:
                return false;
        }
    }

    @Override
    public boolean isSword(ItemStack itemStack) {
        if (itemStack == null) return false;
        switch (itemStack.getType()) {
            case WOODEN_SWORD:
            case STONE_SWORD:
            case IRON_SWORD:
            case GOLDEN_SWORD:
            case DIAMOND_SWORD:
            case NETHERITE_SWORD:
                return true;
            default:
                return false;
        }
    }

    @Override
    public boolean isAxe(ItemStack itemStack) {
        if (itemStack == null) return false;
        switch (itemStack.getType()) {
            case WOODEN_AXE:
            case STONE_AXE:
            case IRON_AXE:
            case GOLDEN_AXE:
            case DIAMOND_AXE:
            case NETHERITE_AXE:
                return true;
            default:
                return false;
        }
    }

    @Override
    public boolean isBow(ItemStack itemStack) {
        return itemStack != null && itemStack.getType() == Material.BOW;
    }

    @Override
    public boolean isProjectile(ItemStack itemStack) {
        if (itemStack == null) return false;
        switch (itemStack.getType()) {
            case ARROW:
            case SPECTRAL_ARROW:
            case TIPPED_ARROW:
            case SNOWBALL:
            case EGG:
            case ENDER_PEARL:
            case TRIDENT:
            case FIRE_CHARGE:
                return true;
            default:
                return false;
        }
    }

    @Override
    public double getDamage(ItemStack i) {
        if (i == null) return 1.0D;
        switch (i.getType()) {
            case WOODEN_SWORD:
            case GOLDEN_SWORD:
                return 4.0D;
            case STONE_SWORD:
                return 5.0D;
            case IRON_SWORD:
                return 6.0D;
            case DIAMOND_SWORD:
                return 7.0D;
            case NETHERITE_SWORD:
                return 8.0D;
            case WOODEN_AXE:
            case GOLDEN_AXE:
                return 7.0D;
            case STONE_AXE:
            case IRON_AXE:
            case DIAMOND_AXE:
                return 9.0D;
            case NETHERITE_AXE:
                return 10.0D;
            case TRIDENT:
                return 9.0D;
            default:
                return 1.0D;
        }
    }

    @Override
    public ItemStack getPlayerHead(Player player, ItemStack copyTagFrom) {
        ItemStack head = new ItemStack(materialPlayerHead());
        if (copyTagFrom != null) {
            String custom = getCustomData(copyTagFrom);
            String tier = getTag(copyTagFrom, PLUGIN_TAG_TIER_KEY);
            if (custom != null) {
                head = setTag(head, PLUGIN_TAG_GENERIC_KEY, custom);
            }
            if (tier != null) {
                head = setTag(head, PLUGIN_TAG_TIER_KEY, tier);
            }
        }
        ItemMeta meta = head.getItemMeta();
        if (meta instanceof SkullMeta) {
            ((SkullMeta) meta).setOwnerProfile(player.getPlayerProfile());
        }
        head.setItemMeta(meta);
        return head;
    }

    @Override
    public void hideEntity(Entity e, Player p) {
        if (e == null || p == null) return;
        if (e instanceof Player) {
            p.hidePlayer(getPlugin(), (Player) e);
            return;
        }
        // Paper per-viewer hide API: works for any entity (armor stand holograms,
        // shop NPCs, etc.). Used to show only the matching-language holograms.
        p.hideEntity(getPlugin(), e);
    }

    @Override
    public void showEntity(Entity e, Player p) {
        if (e == null || p == null) return;
        p.showEntity(getPlugin(), e);
    }

    @Override
    public void setEntityInvisibleByDefault(Entity e) {
        if (e == null) return;
        e.setVisibleByDefault(false);
    }

    @Override
    public String getShopUpgradeIdentifier(ItemStack itemStack) {
        String id = getTag(itemStack, PLUGIN_TAG_TIER_KEY);
        return id == null ? "" : id;
    }

    @Override
    public ItemStack setShopUpgradeIdentifier(ItemStack itemStack, String identifier) {
        return setTag(itemStack, PLUGIN_TAG_TIER_KEY, identifier);
    }

    @Override
    public void voidKill(Player p) {
        if (p == null) return;
        p.setHealth(0.0D);
    }

    @Override
    public String getMainLevel() {
        String version = Bukkit.getMinecraftVersion();
        return version == null || version.isEmpty() ? "1.21.11" : version;
    }

    @Override
    public void playRedStoneDot(Player player) {
        if (player == null) return;
        try {
            player.getWorld().spawnParticle(
                    Particle.DUST,
                    player.getLocation().add(0, 2.6, 0),
                    1,
                    new Particle.DustOptions(Color.RED, 1.0F)
            );
        } catch (Throwable ignored) {
            // Best-effort only.
        }
    }
}
