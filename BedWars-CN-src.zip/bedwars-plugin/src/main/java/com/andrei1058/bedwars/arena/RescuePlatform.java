package com.andrei1058.bedwars.arena;

import com.andrei1058.bedwars.BedWars;
import com.andrei1058.bedwars.api.arena.IArena;
import com.andrei1058.bedwars.api.configuration.ConfigPath;
import com.andrei1058.bedwars.api.language.Language;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockState;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.Map;

/**
 * Self rescue platform item.
 * ANY blaze rod works as a rescue platform: the player right-clicks it while falling
 * (not on ground, falling down) to spawn a square slime platform below him.
 * No PDC tag / display name checks — any plain blaze rod triggers it.
 * 5 second cooldown between uses; during cooldown the item is not consumed.
 */
public class RescuePlatform {

    /** Cooldown between two activations. */
    private static final long COOLDOWN_MS = 5000L;
    private static final Map<java.util.UUID, Long> cooldowns = new HashMap<>();

    private RescuePlatform() {
    }

    public static boolean isEnabled() {
        return BedWars.shop != null && BedWars.shop.getYml().getBoolean(ConfigPath.SHOP_SPECIAL_RESCUE_PLATFORM_ENABLE);
    }

    /**
     * Any blaze rod counts as a rescue platform — no tag checks at all.
     */
    public static boolean isRescuePlatformItem(ItemStack item) {
        return item != null && item.getType() == Material.BLAZE_ROD;
    }

    public static ItemStack findItem(Player player) {
        ItemStack hand = BedWars.nms.getItemInHand(player);
        if (isRescuePlatformItem(hand)) return hand;
        for (ItemStack item : player.getInventory().getContents()) {
            if (isRescuePlatformItem(item)) {
                return item;
            }
        }
        return null;
    }

    public static void consumeOne(Player player, ItemStack item) {
        if (item == null) return;
        if (item.getAmount() > 1) {
            item.setAmount(item.getAmount() - 1);
        } else {
            player.getInventory().removeItem(item);
        }
        player.updateInventory();
    }

    /**
     * Try to use the rescue platform. Manual activation only:
     * the player has to right-click a blaze rod mid-air (not on ground, falling down).
     * It never triggers automatically. 5s cooldown; during cooldown nothing is consumed.
     *
     * @return true when the platform was spawned.
     */
    public static boolean tryUse(Player player, IArena arena) {
        if (!isEnabled()) {
            player.sendMessage(Language.getPlayerLanguage(player).m("rescue-platform.disabled"));
            return false;
        }

        ItemStack item = findItem(player);
        if (item == null) {
            player.sendMessage(Language.getPlayerLanguage(player).m("rescue-platform.need-item"));
            return false;
        }

        // 5s cooldown
        long now = System.currentTimeMillis();
        long last = cooldowns.getOrDefault(player.getUniqueId(), 0L);
        if (now - last < COOLDOWN_MS) {
            int secs = (int) Math.ceil((COOLDOWN_MS - (now - last)) / 1000.0);
            player.sendMessage(Language.getPlayerLanguage(player).m("rescue-platform.cooldown")
                    .replace("{seconds}", String.valueOf(secs)));
            return false;
        }

        // 手动激活：只有"稳稳站在实心方块上"时才拒绝并提示；空中、掉落、虚空中都直接放行。
        // 注意：不能再用 getVelocity().getY() >= 0 来判定"不在下落"——1.21 服务端在玩家
        // 刚离开方块边缘的瞬间 velocity.y 仍是 0，会导致掉虚空时右键"没有任何反应"。
        if (player.isOnGround() && player.getLocation().subtract(0, 1, 0).getBlock().getType().isSolid()) {
            player.sendMessage(Language.getPlayerLanguage(player).m("rescue-platform.only-air"));
            return false;
        }

        // register cooldown only on successful conditions (item is consumed)
        cooldowns.put(player.getUniqueId(), now);
        consumeOne(player, item);

        int radius = BedWars.shop.getInt(ConfigPath.SHOP_SPECIAL_RESCUE_PLATFORM_RADIUS);
        int time = BedWars.shop.getInt(ConfigPath.SHOP_SPECIAL_RESCUE_PLATFORM_TIME);

        Location location = player.getLocation().clone();
        int platformY = location.getBlockY() - 1;

        Location center = new Location(location.getWorld(), location.getBlockX(), platformY, location.getBlockZ());
        place(center, radius, time);

        player.teleport(new Location(location.getWorld(), center.getBlockX() + 0.5D, platformY + 1, center.getBlockZ() + 0.5D, location.getYaw(), location.getPitch()));
        player.setFallDistance(0.0F);
        player.setVelocity(player.getVelocity().setY(0));

        player.sendMessage(Language.getPlayerLanguage(player).m("rescue-platform.activated"));
        return true;
    }

    /**
     * Spawn a square platform of slime blocks around the given location and remove it after {@code time} seconds.
     */
    public static void place(Location location, int radius, int time) {
        World world = location.getWorld();
        if (world == null) return;
        if (radius < 0) radius = 0;
        if (time < 1) time = 1;

        int blockX = location.getBlockX();
        int blockY = location.getBlockY();
        int blockZ = location.getBlockZ();

        Map<Location, BlockState> original = new HashMap<>();
        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                Block block = world.getBlockAt(blockX + dx, blockY, blockZ + dz);
                // never overwrite beds: the platform would hide the bed and break its hologram
                if (BedWars.nms.isBed(block.getType())) continue;
                original.put(block.getLocation(), block.getState());
                block.setType(Material.SLIME_BLOCK, false);
            }
        }

        Bukkit.getScheduler().runTaskLater(BedWars.plugin, () -> {
            for (Map.Entry<Location, BlockState> entry : original.entrySet()) {
                Block block = entry.getKey().getBlock();
                if (block.getType() == Material.SLIME_BLOCK) {
                    entry.getValue().update(true, false);
                }
            }
        }, (long) time * 20L);
    }
}
