package com.andrei1058.bedwars.commands.bedwars;

import com.andrei1058.bedwars.api.arena.GameState;
import com.andrei1058.bedwars.api.arena.IArena;
import com.andrei1058.bedwars.arena.Arena;
import net.md_5.bungee.api.chat.ClickEvent;
import net.md_5.bungee.api.chat.ComponentBuilder;
import net.md_5.bungee.api.chat.HoverEvent;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * 全服喊话：/hh [内容]
 * 任意玩家（无需 OP/权限）在房间内喊话，全服可见，点击消息中的【点击接受】即可加入该房间。
 */
public class HhCommand extends Command {

    /** 喊话冷却：每个玩家 15 秒 */
    private static final long COOLDOWN_MILLIS = 15_000L;
    private static final Map<UUID, Long> cooldowns = new HashMap<>();

    public HhCommand() {
        super("hh", "全服喊话邀请", "/hh <内容>", Arrays.asList("hanhua", "huang"));
    }

    @Override
    public boolean execute(CommandSender sender, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("§c▪ §7该命令仅玩家可用");
            return true;
        }
        Player p = (Player) sender;

        // 15 秒冷却
        long now = System.currentTimeMillis();
        Long last = cooldowns.get(p.getUniqueId());
        if (last != null && now - last < COOLDOWN_MILLIS) {
            long remain = (COOLDOWN_MILLIS - (now - last)) / 1000L + 1;
            p.sendMessage("§c▪ §7喊话冷却中，请等待 §e" + remain + " §7秒后再试！");
            return true;
        }

        IArena a = Arena.getArenaByPlayer(p);
        if (a == null) {
            p.sendMessage("§c▪ §7你不在任何房间中，无法发起喊话邀请！");
            return true;
        }
        if (a.getStatus() != GameState.waiting && a.getStatus() != GameState.starting) {
            p.sendMessage("§c▪ §7对局已开始或正在结算，无法邀请他人加入！");
            return true;
        }

        String msg = args.length == 0 ? "来一起玩起床战争吧！" : String.join(" ", args);
        if (msg.length() > 100) {
            p.sendMessage("§c▪ §7喊话内容过长（最多 100 字）！");
            return true;
        }

        String arenaName = a.getArenaName();
        int players = a.getPlayers().size();

        TextComponent accept = new TextComponent("§a[点击接受，加入房间]");
        accept.setClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/bw join " + arenaName));
        accept.setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT,
                new ComponentBuilder("§7点击加入房间 §e" + arenaName + "\n§7当前人数：§f" + players).create()));

        for (Player all : Bukkit.getOnlinePlayers()) {
            all.sendMessage("");
            all.sendMessage("§6▪ §l[全服喊话] §r§7" + p.getName() + " §8: §f" + msg);
            all.sendMessage("§7房间：§e" + arenaName + " §7（当前 §f" + players + "§7 人）");
            all.spigot().sendMessage(accept);
            all.sendMessage("");
        }
        cooldowns.put(p.getUniqueId(), now);
        return true;
    }

    @Override
    public List<String> tabComplete(CommandSender sender, String alias, String[] args) throws IllegalArgumentException {
        // 无内容时提示占位用法，不提供具体补全
        return null;
    }
}
