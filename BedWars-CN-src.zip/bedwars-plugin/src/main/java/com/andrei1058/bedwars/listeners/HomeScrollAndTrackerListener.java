package com.andrei1058.bedwars.listeners;

import com.andrei1058.bedwars.BedWars;
import com.andrei1058.bedwars.api.arena.IArena;
import com.andrei1058.bedwars.api.arena.team.ITeam;
import com.andrei1058.bedwars.api.language.Language;
import com.andrei1058.bedwars.arena.Arena;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.inventory.ItemStack;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/**
 * 两个商店功能性物品：
 * 1. 回城卷轴（PAPER，3 绿宝石）：右键开启 6 秒引导，引导期间不能移动/转头，
 *    成功则传送回自己队伍的床（家）。床被摧毁时无法启动/无法传送。
 * 2. 玩家追踪器（COMPASS，10 金锭）：拿在主手自动追踪最近存活的敌方玩家，
 *    每秒刷新指南针指向并在 ActionBar 显示目标与距离。
 */
public class HomeScrollAndTrackerListener implements Listener {

    private static final long TELEPORT_DELAY_MS = 6000L; // 6 秒引导
    private static final Map<UUID, TeleportTask> teleportTasks = new HashMap<>();

    private static class TeleportTask {
        float startYaw;
        float startPitch;
        long endTime;
        Location bed;
    }

    public HomeScrollAndTrackerListener() {
        // 回城引导完成检测：每 5 tick 检查一次
        Bukkit.getScheduler().runTaskTimer(BedWars.plugin, this::checkTeleportTasks, 5L, 5L);
        // 指南针追踪器刷新：每秒一次
        Bukkit.getScheduler().runTaskTimer(BedWars.plugin, this::updateCompasses, 20L, 20L);
    }

    /* ============ 回城卷轴 ============ */

    @EventHandler(priority = EventPriority.HIGH)
    public void onHomeScrollUse(PlayerInteractEvent e) {
        if (e == null) return;
        Player p = e.getPlayer();
        if (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        ItemStack hand = BedWars.nms.getItemInHand(p);
        if (hand == null || hand.getType() != Material.PAPER) return;

        IArena a = Arena.getArenaByPlayer(p);
        if (a == null || !a.isPlayer(p)) return;

        e.setCancelled(true);

        UUID uuid = p.getUniqueId();
        if (teleportTasks.containsKey(uuid)) {
            p.sendMessage(Language.getPlayerLanguage(p).m("home-scroll.channeling"));
            return;
        }

        ITeam team = a.getTeam(p);
        if (team == null) return;
        Location bed = team.getBed();
        if (bed == null || !BedWars.nms.isBed(bed.getBlock().getType())) {
            p.sendMessage(Language.getPlayerLanguage(p).m("home-scroll.no-bed"));
            return;
        }

        TeleportTask task = new TeleportTask();
        task.startYaw = p.getLocation().getYaw();
        task.startPitch = p.getLocation().getPitch();
        task.endTime = System.currentTimeMillis() + TELEPORT_DELAY_MS;
        task.bed = bed.clone();
        teleportTasks.put(uuid, task);

        p.sendMessage(Language.getPlayerLanguage(p).m("home-scroll.start"));
        BedWars.nms.sendTitle(p, "", Language.getPlayerLanguage(p).m("home-scroll.title"), 5, 115, 5);
    }

    @EventHandler
    public void onMove(PlayerMoveEvent e) {
        Player p = e.getPlayer();
        UUID uuid = p.getUniqueId();
        TeleportTask task = teleportTasks.get(uuid);
        if (task == null) return;

        Location from = e.getFrom();
        Location to = e.getTo();
        if (to == null) return;

        boolean moved = from.getBlockX() != to.getBlockX()
                || from.getBlockY() != to.getBlockY()
                || from.getBlockZ() != to.getBlockZ()
                || Math.abs(to.getYaw() - task.startYaw) > 5.0F
                || Math.abs(to.getPitch() - task.startPitch) > 5.0F;
        if (moved) {
            teleportTasks.remove(uuid);
            p.sendMessage(Language.getPlayerLanguage(p).m("home-scroll.cancelled"));
            BedWars.nms.sendTitle(p, "", "", 0, 10, 0);
        }
    }

    private void checkTeleportTasks() {
        long now = System.currentTimeMillis();
        Iterator<Map.Entry<UUID, TeleportTask>> it = teleportTasks.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, TeleportTask> entry = it.next();
            TeleportTask task = entry.getValue();
            if (now < task.endTime) continue;
            it.remove();
            Player p = Bukkit.getPlayer(entry.getKey());
            if (p == null || !p.isOnline()) continue;

            // 引导期间床被摧毁：不传送、不消耗
            if (task.bed == null || !BedWars.nms.isBed(task.bed.getBlock().getType())) {
                p.sendMessage(Language.getPlayerLanguage(p).m("home-scroll.no-bed"));
                BedWars.nms.sendTitle(p, "", "", 0, 10, 0);
                continue;
            }

            Location bed = task.bed;
            p.teleport(bed.clone().add(0.5D, 1.5D, 0.5D));
            p.setFallDistance(0.0F);
            p.sendMessage(Language.getPlayerLanguage(p).m("home-scroll.success"));
            BedWars.nms.sendTitle(p, "", "", 0, 10, 0);

            // 消耗一个卷轴
            ItemStack hand = BedWars.nms.getItemInHand(p);
            if (hand != null && hand.getType() == Material.PAPER) {
                BedWars.nms.minusAmount(p, hand, 1);
            }
        }
    }

    /* ============ 玩家追踪器（指南针） ============ */

    private void updateCompasses() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            IArena a = Arena.getArenaByPlayer(p);
            if (a == null || !a.isPlayer(p)) continue;
            ItemStack hand = BedWars.nms.getItemInHand(p);
            if (hand == null || hand.getType() != Material.COMPASS) continue;

            ITeam myTeam = a.getTeam(p);
            Player nearest = null;
            double minDist = Double.MAX_VALUE;

            for (Player t : Bukkit.getOnlinePlayers()) {
                if (t.equals(p)) continue;
                IArena ta = Arena.getArenaByPlayer(t);
                if (ta == null || !ta.equals(a)) continue;
                if (!ta.isPlayer(t)) continue; // 排除观战者
                ITeam tt = ta.getTeam(t);
                if (tt == null || myTeam == null || tt.equals(myTeam)) continue; // 排除队友
                double d = p.getLocation().distance(t.getLocation());
                if (d < minDist) {
                    minDist = d;
                    nearest = t;
                }
            }

            if (nearest == null) {
                p.setCompassTarget(p.getWorld().getSpawnLocation());
                sendActionBar(p, "§7玩家追踪器：§c附近没有存活敌人");
            } else {
                p.setCompassTarget(nearest.getLocation());
                sendActionBar(p, "§e玩家追踪器：§f" + nearest.getName() + " §7距离 §e" + String.format("%.1f", minDist) + "§7 格");
            }
        }
    }

    /** 反射调用 Player#sendActionBar（编译 API 1.14 无此方法，运行时 Paper 1.21.11 存在）。 */
    private static void sendActionBar(Player p, String msg) {
        try {
            java.lang.reflect.Method m = Player.class.getMethod("sendActionBar", String.class);
            m.invoke(p, msg);
        } catch (Throwable t) {
            try {
                BedWars.nms.sendTitle(p, "", msg, 0, 40, 0);
            } catch (Throwable ignored) {
            }
        }
    }
}
