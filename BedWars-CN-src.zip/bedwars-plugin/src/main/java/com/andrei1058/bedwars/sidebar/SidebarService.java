package com.andrei1058.bedwars.sidebar;

import com.andrei1058.bedwars.BedWars;
import com.andrei1058.bedwars.api.arena.GameState;
import com.andrei1058.bedwars.api.arena.IArena;
import com.andrei1058.bedwars.api.arena.team.ITeam;
import com.andrei1058.bedwars.api.configuration.ConfigPath;
import com.andrei1058.bedwars.api.events.sidebar.PlayerSidebarInitEvent;
import com.andrei1058.bedwars.api.language.Language;
import com.andrei1058.bedwars.api.language.Messages;
import com.andrei1058.bedwars.api.server.ServerType;
import com.andrei1058.bedwars.api.sidebar.ISidebar;
import com.andrei1058.bedwars.api.sidebar.ISidebarService;
import com.andrei1058.bedwars.metrics.MetricsManager;
import com.andrei1058.bedwars.sidebar.thread.*;
import com.andrei1058.spigot.sidebar.Sidebar;
import com.andrei1058.spigot.sidebar.SidebarManager;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.plugin.java.JavaPlugin;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.*;

import static com.andrei1058.bedwars.BedWars.config;
import static com.andrei1058.bedwars.api.language.Language.getScoreboard;

public class SidebarService implements ISidebarService {

    private static SidebarService instance;

    private final SidebarManager sidebarHandler;
    private final HashMap<UUID, BwSidebar> sidebars = new HashMap<>();

    public static boolean init(JavaPlugin plugin) {
        if (null == instance) {
            instance = new SidebarService();

            var log = Bukkit.getLogger();

            int playerListRefreshInterval = config.getInt(ConfigPath.SB_CONFIG_SIDEBAR_LIST_REFRESH);
            if (playerListRefreshInterval < 1) {
                Bukkit.getLogger().info("计分板玩家列表刷新已禁用。（当前设置为 " + playerListRefreshInterval + "）。");
            } else {
                if (playerListRefreshInterval < 20) {
                    log.warning("计分板玩家列表刷新间隔设置为: " + playerListRefreshInterval);
                    log.warning("不建议使用小于 20 tick 的值。");
                    log.warning("如果你预期会出现性能问题，请增大该计时器。");
                }
                Bukkit.getScheduler().runTaskTimer(plugin, new RefreshPlayerListTask(), 1L, playerListRefreshInterval);
            }
            MetricsManager.appendPie("sb_list_refresh_interval", () -> String.valueOf(playerListRefreshInterval));

            int placeholdersRefreshInterval = config.getInt(ConfigPath.SB_CONFIG_SIDEBAR_PLACEHOLDERS_REFRESH_INTERVAL);
            if (placeholdersRefreshInterval < 1) {
                log.info("计分板占位符刷新已禁用。（当前设置为 " + placeholdersRefreshInterval + "）。");
            } else {
                if (placeholdersRefreshInterval < 20) {
                    log.warning("计分板占位符刷新间隔设置为: " + placeholdersRefreshInterval);
                    log.warning("不建议使用小于 20 tick 的值。");
                    log.warning("如果你预期会出现性能问题，请增大该计时器。");
                }
                Bukkit.getScheduler().runTaskTimer(plugin, new RefreshPlaceholdersTask(), 1L, placeholdersRefreshInterval);
            }
            MetricsManager.appendPie("sb_placeholder_refresh_interval", () -> String.valueOf(placeholdersRefreshInterval));

            int titleRefreshInterval = config.getInt(ConfigPath.SB_CONFIG_SIDEBAR_TITLE_REFRESH_INTERVAL);
            if (titleRefreshInterval < 1) {
                log.info("计分板标题刷新已禁用。（当前设置为 " + titleRefreshInterval + "）。");
            } else {
                if (titleRefreshInterval < 4) {
                    log.warning("计分板标题刷新间隔设置为: " + titleRefreshInterval);
                    log.warning("如果你预期会出现性能问题，请增大该计时器。");
                }
                Bukkit.getScheduler().runTaskTimerAsynchronously(plugin, new RefreshTitleTask(), 1L, titleRefreshInterval);
            }
            MetricsManager.appendPie("sb_title_refresh_interval", () -> String.valueOf(titleRefreshInterval));

            int healthAnimationInterval = config.getInt(ConfigPath.SB_CONFIG_SIDEBAR_HEALTH_REFRESH);
            if (healthAnimationInterval < 1) {
                log.info("Scoreboard health animation refresh is disabled. (It is set to " + healthAnimationInterval + ").");
            } else {
                if (healthAnimationInterval < 20) {
                    log.warning("Scoreboard health animation refresh interval is set to: " + healthAnimationInterval);
                    log.warning("It is not recommended to use a value under 20 ticks.");
                    log.warning("If you expect performance issues please increase its timer.");
                }
                Bukkit.getScheduler().scheduleSyncRepeatingTask(plugin, new RefreshLifeTask(), 1L, healthAnimationInterval);
            }
            MetricsManager.appendPie("sb_health_refresh_interval", () -> String.valueOf(healthAnimationInterval));

            int tabHeaderFooterRefreshInterval = config.getInt(ConfigPath.SB_CONFIG_TAB_HEADER_FOOTER_REFRESH_INTERVAL);
            if (tabHeaderFooterRefreshInterval < 1 || !config.getBoolean(ConfigPath.SB_CONFIG_TAB_HEADER_FOOTER_ENABLE)) {
                log.info("Scoreboard Tab header-footer refresh is disabled.");
            } else {
                if (tabHeaderFooterRefreshInterval < 20) {
                    log.warning("Scoreboard tab header-footer refresh interval is set to: " + tabHeaderFooterRefreshInterval);
                    log.warning("It is not recommended to use a value under 20 ticks.");
                    log.warning("If you expect performance issues please increase its timer.");
                }
                Bukkit.getScheduler().runTaskTimer(plugin, new RefreshTabHeaderFooterTask(), 1L, tabHeaderFooterRefreshInterval);
            }
            MetricsManager.appendPie("sb_header_footer_refresh_interval", () -> String.valueOf(tabHeaderFooterRefreshInterval));

            // login-plugin restore: re-apply the sidebar/tab if a login plugin replaced the scoreboard
            Bukkit.getScheduler().runTaskTimer(plugin, new RefreshLoginRestoreTask(), 60L, 40L);

            var lobbySidebar = config.getBoolean(ConfigPath.SB_CONFIG_SIDEBAR_USE_LOBBY_SIDEBAR) &&
                    BedWars.getServerType() == ServerType.MULTIARENA;
            MetricsManager.appendPie("sb_lobby_enable", () -> String.valueOf(lobbySidebar));
            var gameSidebar = config.getBoolean(ConfigPath.SB_CONFIG_SIDEBAR_USE_GAME_SIDEBAR);
            MetricsManager.appendPie("sb_game_enable", () -> String.valueOf(gameSidebar));

            BedWars.registerEvents(new ScoreboardListener());
        }
        return instance.sidebarHandler != null;
    }

    private SidebarService() {
        sidebarHandler = SidebarManager.init();
    }

    public void giveSidebar(@NotNull Player player, @Nullable IArena arena, boolean delay) {
        BwSidebar sidebar = sidebars.getOrDefault(player.getUniqueId(), null);

        // check if we might need to remove the existing sidebar
        if (null != sidebar) {
            if (null == arena) {
                // if sidebar is disabled in lobby on shared or multi-arena mode
                if (!config.getBoolean(ConfigPath.SB_CONFIG_SIDEBAR_USE_LOBBY_SIDEBAR) ||
                        BedWars.getServerType() == ServerType.SHARED) {
                    this.remove(sidebar);
                    return;
                }
            } else {
                // if sidebar is disabled in game
                if (!config.getBoolean(ConfigPath.SB_CONFIG_SIDEBAR_USE_GAME_SIDEBAR)) {
                    this.remove(sidebar);
                    return;
                }
            }
        }

        // if sidebar was null but still disabled for lobbies
        if (!config.getBoolean(ConfigPath.SB_CONFIG_SIDEBAR_USE_LOBBY_SIDEBAR) && null == arena) {
            return;
        }
        // if sidebar was null but still disabled in game
        if (!config.getBoolean(ConfigPath.SB_CONFIG_SIDEBAR_USE_GAME_SIDEBAR) && null != arena) {
            return;
        }

        // set sidebar lines based on game state or lobby
        List<String> lines = null;
        List<String> title;
        if (null == arena) {
            if (BedWars.getServerType() != ServerType.SHARED) {
                // 优先读 ce.yml（服主自定义侧边栏）
                lines = ExternalTextConfig.getSidebarLines("lobby");
                if (lines == null) lines = Language.getList(player, Messages.SCOREBOARD_LOBBY);
            }
        } else {
            if (arena.getStatus() == GameState.waiting) {
                lines = ExternalTextConfig.getSidebarLines("waiting");
                if (lines == null) {
                    if (arena.isSpectator(player)) {
                        lines = getScoreboard(player, "sidebar." + arena.getGroup() + ".waiting.spectator", Messages.SCOREBOARD_DEFAULT_WAITING_SPEC);
                    } else {
                        lines = getScoreboard(player, "sidebar." + arena.getGroup() + ".waiting.player", Messages.SCOREBOARD_DEFAULT_WAITING);
                    }
                }
            } else if (arena.getStatus() == GameState.starting) {
                lines = ExternalTextConfig.getSidebarLines("starting");
                if (lines == null) {
                    if (arena.isSpectator(player)) {
                        lines = getScoreboard(player, "sidebar." + arena.getGroup() + ".starting.spectator", Messages.SCOREBOARD_DEFAULT_STARTING_SPEC);
                    } else {
                        lines = getScoreboard(player, "sidebar." + arena.getGroup() + ".starting.player", Messages.SCOREBOARD_DEFAULT_STARTING);
                    }
                }
            } else if (arena.getStatus() == GameState.playing) {
                if (arena.isSpectator(player)) {
                    lines = ExternalTextConfig.getSidebarLines("playing_spectator");
                    if (lines == null) {
                        ITeam holderExTeam = arena.getExTeam(player.getUniqueId());
                        if (null == holderExTeam) {
                            lines = getScoreboard(player, "sidebar." + arena.getGroup() + ".playing.spectator", Messages.SCOREBOARD_DEFAULT_PLAYING_SPEC);
                        } else {
                            lines = getScoreboard(player, "sidebar." + arena.getGroup() + ".playing.eliminated", Messages.SCOREBOARD_DEFAULT_PLAYING_SPEC_ELIMINATED);
                        }
                    }
                } else {
                    lines = ExternalTextConfig.getSidebarLines("playing");
                    if (lines == null) {
                        lines = getScoreboard(player, "sidebar." + arena.getGroup() + ".playing.alive", Messages.SCOREBOARD_DEFAULT_PLAYING);
                    }
                }
            } else if (arena.getStatus() == GameState.restarting) {
                ITeam holderTeam = arena.getTeam(player);
                ITeam holderExTeam = null == holderTeam ? arena.getExTeam(player.getUniqueId()) : null;

                // 判断胜者/败者
                boolean isWinner = false;
                if (arena.getWinner() != null) {
                    if (holderTeam != null && holderTeam.equals(arena.getWinner())) isWinner = true;
                    else if (holderExTeam != null && holderExTeam.equals(arena.getWinner())) isWinner = true;
                }
                lines = ExternalTextConfig.getSidebarLines(isWinner ? "restarting_win" : "restarting_lose");
                if (lines == null) {
                    if (null == holderTeam && null == holderExTeam) {
                        lines = getScoreboard(player, "sidebar." + arena.getGroup() + ".restarting.spectator", Messages.SCOREBOARD_DEFAULT_RESTARTING_SPEC);
                    } else {
                        if (null == holderTeam && holderExTeam.equals(arena.getWinner())) {
                            lines = getScoreboard(player, "sidebar." + arena.getGroup() + ".restarting.winner-eliminated", Messages.SCOREBOARD_DEFAULT_RESTARTING_WIN2);
                        } else if (null == holderExTeam && holderTeam.equals(arena.getWinner())) {
                            lines = getScoreboard(player, "sidebar." + arena.getGroup() + ".restarting.winner-alive", Messages.SCOREBOARD_DEFAULT_RESTARTING_WIN1);
                        } else {
                            lines = getScoreboard(player, "sidebar." + arena.getGroup() + ".restarting.loser", Messages.SCOREBOARD_DEFAULT_RESTARTING_LOSER);
                        }
                    }
                }
            }
        }

        // if we do not have lines we eventually remove the sidebar
        if (null == lines || lines.isEmpty()) {
            if (null != sidebar) {
                this.remove(sidebar);
            }
            return;
        }

        // title is the first line from array
        title = new ArrayList<>(Arrays.asList(lines.get(0).split(",")));
        if (lines.size() == 1) {
            lines = new ArrayList<>();
        }
        lines = lines.subList(1, lines.size());

        // at this point we are sure we need a sidebar instance
        boolean newlyAdded = false;
        if (null == sidebar) {
            sidebar = new BwSidebar(player);
            newlyAdded = true;

            PlayerSidebarInitEvent event = new PlayerSidebarInitEvent(player, sidebar);
            Bukkit.getPluginManager().callEvent(event);
            if (event.isCancelled()) {
                return;
            }
        }
        sidebar.setContent(title, lines, arena);

        if (newlyAdded) {
            sidebars.put(player.getUniqueId(), sidebar);
        }
    }

    /**
     * Kill a sidebar lifecycle.
     */
    public void remove(@NotNull BwSidebar sidebar) {
        this.sidebars.remove(sidebar.getPlayer().getUniqueId());
        sidebar.remove();
    }

    public void remove(@NotNull Player player) {
        BwSidebar sidebar = this.sidebars.remove(player.getUniqueId());
        if (null != sidebar) {
            sidebar.remove();
        }
    }

    /**
     * Re-apply the sidebar and tab list to players whose scoreboard was replaced
     * by a login plugin (e.g. AuthMe) after they logged in.
     */
    public void restoreForLoggedPlayers() {
        this.sidebars.forEach((uuid, sidebar) -> {
            Player player = Bukkit.getPlayer(uuid);
            if (player == null || !player.isOnline()) return;
            if (!isAuthenticated(player)) return;
            Sidebar handle = sidebar.getHandle();
            if (handle == null) return;
            Scoreboard expected = getSidebarScoreboard(handle);
            if (expected == null) return;
            if (player.getScoreboard() != expected) {
                handle.add(player);
                sidebar.giveUpdateTabFormat(player, true, null);
                giveSidebar(player, sidebar.getArena(), false);
            }
        });
    }

    /**
     * Check whether the player passed the login gate of installed login plugins.
     * If no login plugin is present, always returns true.
     */
    private static boolean isAuthenticated(Player p) {
        try {
            org.bukkit.plugin.Plugin authme = Bukkit.getPluginManager().getPlugin("AuthMe");
            if (authme == null) return true;
            Class<?> api = Class.forName("fr.xephi.authme.api.v3.AuthMeApi");
            Object instance = api.getMethod("getInstance").invoke(null);
            Object result = api.getMethod("isAuthenticated", org.bukkit.entity.Player.class).invoke(instance, p);
            return result instanceof Boolean && (Boolean) result;
        } catch (Exception ignored) {
            return true;
        }
    }

    private static Scoreboard getSidebarScoreboard(Sidebar handle) {
        if (handle instanceof com.andrei1058.spigot.sidebar.v1_21_11.SidebarImpl) {
            return ((com.andrei1058.spigot.sidebar.v1_21_11.SidebarImpl) handle).getScoreboard();
        }
        return null;
    }

    public static SidebarService getInstance() {
        return instance;
    }

    protected SidebarManager getSidebarHandler() {
        return sidebarHandler;
    }

    public void refreshTitles() {
        this.sidebars.forEach((k, v) -> v.getHandle().refreshTitle());
    }

    public void refreshPlaceholders() {
        this.sidebars.forEach((k, v) -> v.getHandle().refreshPlaceholders());
    }

    public void refreshPlaceholders(IArena arena) {
        this.sidebars.forEach((k, v) -> {
            if (v.getArena() != null)
                if (v.getArena().equals(arena)) {
                    v.getHandle().refreshPlaceholders();
                }
        });
    }

    public void refreshTabList() {
        this.sidebars.forEach((k, v) -> v.getHandle().playerTabRefreshAnimation());
    }

    public void refreshTabHeaderFooter() {
        this.sidebars.forEach((k, v) -> {
            if (null != v && null != v.getHeaderFooter()) {
                this.sidebarHandler.sendHeaderFooter(v.getPlayer(), v.getHeaderFooter());
            }
        });
    }

    public void refreshHealth() {
        this.sidebars.forEach((k, v) -> {
            if (null != v.getArena()) {
                v.getHandle().playerHealthRefreshAnimation();
                for (Player player : v.getArena().getPlayers()) {
                    v.getHandle().setPlayerHealth(player, (int) Math.ceil(player.getHealth()));
                }
            }
        });
    }

    @Override
    public @Nullable ISidebar getSidebar(@NotNull Player player) {
        return this.sidebars.getOrDefault(player.getUniqueId(), null);
    }

    public void refreshHealth(IArena arena, Player player, int health) {
        this.sidebars.forEach((k, v) -> {
            if (null != v.getArena() && v.getArena().equals(arena)) {
                v.getHandle().setPlayerHealth(player, health);
            }
        });
    }

    public void handleReJoin(IArena arena, Player player) {
        this.sidebars.forEach((k, v) -> {
            if (null != v.getArena() && v.getArena().equals(arena)) {
                v.giveUpdateTabFormat(player, false);
            }
        });
    }

    public void handleJoin(IArena arena, Player player, @Nullable Boolean spectator) {
        this.sidebars.forEach((k, v) -> {
            if (null != v.getArena() && v.getArena().equals(arena)) {
                if (!v.getPlayer().equals(player)) {
                    v.giveUpdateTabFormat(player, false, spectator);
                }
            }
        });
    }

    public void applyLobbyTab(Player player) {
        this.sidebars.forEach((k, v) -> {
            if (null == v.getArena()) {
                if (!v.getPlayer().equals(player)) {
                    v.giveUpdateTabFormat(player, false);
                }
            }
        });
    }

    public void handleInvisibility(ITeam team, Player player, boolean toggle) {
        this.sidebars.forEach((k, v) -> {
            if (null != v.getArena() && v.getArena().equals(team.getArena())) {
                v.handleInvisibilityPotion(player, toggle);
            }
        });
    }
}
