/*
 * BedWars1058 - A bed wars mini-game.
 * Copyright (C) 2021 Andrei Dascălu
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 * Contact e-mail: andrew.dascalu@gmail.com
 */

package com.andrei1058.bedwars.upgrades.menu;

import com.andrei1058.bedwars.BedWars;
import com.andrei1058.bedwars.api.arena.team.ITeam;
import com.andrei1058.bedwars.api.language.Language;
import com.andrei1058.bedwars.api.language.Messages;
import com.andrei1058.bedwars.api.upgrades.MenuContent;
import com.andrei1058.bedwars.upgrades.UpgradesManager;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MenuCategory implements MenuContent {

    private ItemStack displayItem;
    private String name;

    private HashMap<Integer, MenuContent> menuContentBySlot = new HashMap<>();

    /**
     * Chinese category display name for the default BedWars categories.
     * Falls back to the raw category key when unknown.
     */
    private static String getChineseCategoryName(String catName) {
        switch (catName) {
            case "blocks": return "方块";
            case "melee": return "近战武器";
            case "armor": return "护甲";
            case "tools": return "工具";
            case "ranged": return "远程武器";
            case "potions": return "药水";
            case "utility": return "实用物品";
            default: return catName;
        }
    }

    public MenuCategory(String name, ItemStack displayItem) {
        this.name = name;
        this.displayItem = BedWars.nms.addCustomData(displayItem, "MCONT_" + name);
        String catName = name.replace("category-", "");
        String catGuiPath = Messages.UPGRADES_CATEGORY_GUI_NAME_PATH + catName;
        String catItemPath = Messages.UPGRADES_CATEGORY_ITEM_NAME_PATH + catName;
        String catLorePath = Messages.UPGRADES_CATEGORY_ITEM_LORE_PATH + catName;
        for (Language lang : Language.getLanguages()) {
            if (lang.getYml().get(catGuiPath) == null) {
                if (lang.getIso().equals("zh_cn")) {
                    // 简体中文分类名映射，避免显示英文分类 key
                    String zhCat = getChineseCategoryName(catName);
                    lang.set(catGuiPath, "&8" + zhCat);
                } else {
                    lang.set(catGuiPath, "&8" + name);
                }
            }
            if (lang.getYml().get(catItemPath) == null) {
                lang.set(catItemPath, lang.getIso().equals("zh_cn") ? "&c未设置名称" : "&cName not set");
            } else if (lang.getIso().equals("zh_cn") && "&cName not set".equals(lang.getYml().getString(catItemPath))) {
                lang.set(catItemPath, "&c未设置名称");
            }
            if (lang.getYml().get(catLorePath) == null) {
                lang.set(catLorePath, lang.getIso().equals("zh_cn") ? Collections.singletonList("&c未设置描述") : Collections.singletonList("&cLore not set"));
            } else if (lang.getIso().equals("zh_cn") && lang.getYml().get(catLorePath) != null && lang.getYml().get(catLorePath).toString().contains("Lore not set")) {
                lang.set(catLorePath, Collections.singletonList("&c未设置描述"));
            }
        }
    }

    /**
     * Add content to a menu.
     *
     * @param content content instance.
     * @param slot    where to put the content in the menu.
     * @return false if te given slot is in use.
     */
    public boolean addContent(MenuContent content, int slot) {
        if (menuContentBySlot.get(slot) != null) return false;
        menuContentBySlot.put(slot, content);
        return true;
    }

    @Override
    public ItemStack getDisplayItem(Player player, ITeam team) {
        ItemStack i = new ItemStack(displayItem);
        ItemMeta im = i.getItemMeta();
        if (im != null) {
            im.setDisplayName(Language.getMsg(player, Messages.UPGRADES_CATEGORY_ITEM_NAME_PATH + name.replace("category-", "")));
            List<String> lore = Language.getList(player, Messages.UPGRADES_CATEGORY_ITEM_LORE_PATH + name.replace("category-", ""));

            if (name.equalsIgnoreCase("traps")) {
                int queueLimit = UpgradesManager.getConfiguration().getInt(team.getArena().getGroup().toLowerCase() + "-upgrades-settings.trap-queue-limit");
                if (queueLimit == 0) {
                    queueLimit = UpgradesManager.getConfiguration().getInt("default-upgrades-settings.trap-queue-limit");
                }
                if (queueLimit == team.getActiveTraps().size()) {
                    lore.add("");
                    lore.add(Language.getMsg(player, Messages.UPGRADES_TRAP_QUEUE_LIMIT));
                }
            }
            im.setLore(lore);
            i.setItemMeta(im);
        }
        return i;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void onClick(Player player, ClickType clickType, ITeam team) {
        if (name.equalsIgnoreCase("category-traps")){
            int queueLimit = UpgradesManager.getConfiguration().getInt(team.getArena().getGroup().toLowerCase()+"-upgrades-settings.trap-queue-limit");
            if (queueLimit == 0){
                queueLimit = UpgradesManager.getConfiguration().getInt("default-upgrades-settings.trap-queue-limit");
            }
            if (queueLimit <= team.getActiveTraps().size()){
                player.sendMessage(Language.getMsg(player, Messages.UPGRADES_TRAP_QUEUE_LIMIT));
                return;
            }
        }
        Inventory inv = Bukkit.createInventory(null, 45, Language.getMsg(player, Messages.UPGRADES_CATEGORY_GUI_NAME_PATH + name.replace("category-", "")));
        for (Map.Entry<Integer, MenuContent> entry : menuContentBySlot.entrySet()) {
            inv.setItem(entry.getKey(), entry.getValue().getDisplayItem(player, team));
        }
        player.openInventory(inv);
        UpgradesManager.setWatchingUpgrades(player.getUniqueId());
    }

}
