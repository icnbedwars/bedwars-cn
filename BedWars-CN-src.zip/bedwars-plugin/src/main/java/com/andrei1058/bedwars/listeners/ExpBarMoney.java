package com.andrei1058.bedwars.listeners;

import com.andrei1058.bedwars.BedWars;
import com.andrei1058.bedwars.api.arena.IArena;
import com.andrei1058.bedwars.arena.Arena;
import com.andrei1058.bedwars.shop.main.CategoryContent;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerPickupItemEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashMap;
import java.util.Map;

/**
 * 按地图启用的经验模式：每个地图（arena）可在自己的 config.yml 里设置
 * experience-mode.enable=true 来启用。启用后，该地图玩家背包里的铁/金/钻石/绿宝石
 * 会按配置的经验值（铁=2、金=7、钻石=20、绿宝石=100）折算，实时显示在经验条上
 * （level = 总经验，经验条半满）。只影响显示，不改变货币/商店机制。
 * 未启用经验模式的地图或大厅不显示。
 */
public class ExpBarMoney implements Listener {

    private static final Map<Material, Integer> VALUES = new HashMap<>();
    private static BukkitTask task;

    public ExpBarMoney() {
    }

    /** 由插件启动时调用：启动经验条刷新任务（是否生效按玩家所在地图配置决定） */
    public static void init() {
        if (task != null) {
            task.cancel();
            task = null;
        }
        VALUES.clear();
        task = Bukkit.getScheduler().runTaskTimer(BedWars.plugin, ExpBarMoney::refreshAll, 10L, 10L);
    }

    private static void refreshAll() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            refresh(p);
        }
    }

    /** 读取玩家所在地图的经验模式配置并更新经验条 */
    public static void refresh(Player p) {
        if (p == null || !p.isOnline()) return;
        IArena a = Arena.getArenaByPlayer(p);
        if (a == null || !a.isPlayer(p)) {
            // 不在对局内：恢复空经验条（游戏内玩家等级本为 0）
            if (p.getLevel() != 0 || p.getExp() != 0f) {
                p.setLevel(0);
                p.setExp(0f);
            }
            return;
        }
        org.bukkit.configuration.file.YamlConfiguration cfg = a.getConfig().getYml();
        if (!cfg.getBoolean("experience-mode.enable", false)) {
            if (p.getLevel() != 0 || p.getExp() != 0f) {
                p.setLevel(0);
                p.setExp(0f);
            }
            return;
        }
        // 经验货币模式：level 即经验货币余额（由拾取转经验 / 商店经验支付维护），这里只保持经验条半满显示
        p.setExp(0.5f);
    }

    @EventHandler
    public void onPickup(PlayerPickupItemEvent e) {
        Player p = e.getPlayer();
        if (p == null || !p.isOnline()) return;
        // 经验货币模式：铁/金/钻石/绿宝石拾取时直接折算成经验发给玩家（不进背包）
        if (CategoryContent.isExpMode(p)) {
            Material m = e.getItem().getItemStack().getType();
            int unit = CategoryContent.expValue(p, m);
            if (unit > 0) {
                int amount = e.getItem().getItemStack().getAmount();
                e.setCancelled(true);
                e.getItem().remove();
                p.setLevel(p.getLevel() + unit * amount);
                p.setExp(0.5f);
            }
        }
    }
}
