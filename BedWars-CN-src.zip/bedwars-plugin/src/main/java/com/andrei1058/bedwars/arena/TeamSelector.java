package com.andrei1058.bedwars.arena;

import com.andrei1058.bedwars.api.arena.GameState;
import com.andrei1058.bedwars.api.arena.IArena;
import com.andrei1058.bedwars.api.arena.team.ITeam;
import com.andrei1058.bedwars.api.language.Language;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.DyeColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Native team selector. Gives every waiting player a chest item that opens a GUI
 * where they can pick their team before the game starts.
 */
public class TeamSelector {

    public static final Map<UUID, Session> sessions = new ConcurrentHashMap<>();

    private TeamSelector() {
    }

    public static void giveItem(Player p) {
        if (p == null) return;
        Language lang = Language.getPlayerLanguage(p);
        String name = ChatColor.translateAlternateColorCodes('&', lang.m("team-selector.item-name"));
        List<String> lore = lang.getYml().getStringList("team-selector.item-lore");
        List<String> colored = new ArrayList<>();
        for (String line : lore) {
            colored.add(ChatColor.translateAlternateColorCodes('&', line));
        }
        ItemStack item = Misc.createItem(Material.CHEST, (byte) 0, false, name, colored, p, "RUNCOMMAND", "bw selectTeam");
        p.getInventory().setItem(0, item);
        p.updateInventory();
    }

    public static void open(Player p, IArena arena) {
        if (p == null || arena == null) return;
        // 等待期间与倒计时期间都可以选队；游戏正式开始后禁止
        GameState st = arena.getStatus();
        if (st != GameState.waiting && st != GameState.starting) {
            p.sendMessage(Language.getPlayerLanguage(p).m("team-selector.only-waiting"));
            return;
        }
        List<ITeam> teams = arena.getTeams();
        if (teams == null || teams.isEmpty()) return;
        int rows = Math.max(1, (int) Math.ceil((double) teams.size() / 9.0));
        Language lang = Language.getPlayerLanguage(p);
        Inventory inv = Bukkit.createInventory(null, rows * 9, ChatColor.translateAlternateColorCodes('&', lang.m("team-selector.gui-name")));
        Session s = new Session(arena);
        int slot = 0;
        for (ITeam t : teams) {
            if (slot >= rows * 9) break;
            s.slots.put(slot, t);
            inv.setItem(slot, makeItem(p, t, lang));
            slot++;
        }
        sessions.put(p.getUniqueId(), s);
        p.openInventory(inv);
    }

    private static ItemStack makeItem(Player p, ITeam t, Language lang) {
        DyeColor dye = t.getColor().dye();
        Material mat = Material.matchMaterial(dye.name() + "_STAINED_GLASS");
        if (mat == null) mat = Material.GLASS;
        ItemStack item = new ItemStack(mat);
        ItemMeta im = item.getItemMeta();
        if (im == null) return item;
        im.setDisplayName(ChatColor.translateAlternateColorCodes('&', t.getDisplayName(lang)));
        int members = t.getMembers().size();
        int max = t.getArena().getMaxInTeam();
        boolean full = members >= max;
        String status = full ? lang.m("team-selector.team-lore-full") : lang.m("team-selector.team-lore");
        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.translateAlternateColorCodes('&', status.replace("{members}", String.valueOf(members)).replace("{max}", String.valueOf(max))));
        if (t.isMember(p)) {
            lore.add(ChatColor.translateAlternateColorCodes('&', lang.m("team-selector.selected")));
        }
        im.setLore(lore);
        item.setItemMeta(im);
        return item;
    }

    public static class Session {
        public final IArena arena;
        public final Map<Integer, ITeam> slots = new HashMap<>();

        public Session(IArena arena) {
            this.arena = arena;
        }
    }
}
