package com.andrei1058.bedwars.commands.bedwars.subcmds.regular;

import com.andrei1058.bedwars.api.arena.IArena;
import com.andrei1058.bedwars.api.command.ParentCommand;
import com.andrei1058.bedwars.api.command.SubCommand;
import com.andrei1058.bedwars.api.language.Language;
import com.andrei1058.bedwars.api.language.Messages;
import com.andrei1058.bedwars.arena.Arena;
import com.andrei1058.bedwars.arena.TeamSelector;
import com.andrei1058.bedwars.commands.bedwars.MainCommand;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

public class CmdSelectTeam extends SubCommand {

    public CmdSelectTeam(ParentCommand parent, String name) {
        super(parent, name);
        this.setPriority(21);
        this.showInList(true);
        this.setDisplayInfo(MainCommand.createTC(
                "§6 ▪ §7/" + MainCommand.getInstance().getName() + " " + this.getSubCommandName(),
                "/" + this.getParent().getName() + " " + this.getSubCommandName(),
                "§fOpen the team selector."));
    }

    @Override
    public boolean execute(String[] args, CommandSender s) {
        if (!(s instanceof Player)) {
            return false;
        }
        Player p = (Player) s;
        IArena arena = Arena.getArenaByPlayer(p);
        if (arena == null) {
            p.sendMessage(Language.getMsg(p, Messages.COMMAND_JOIN_USAGE));
            return true;
        }
        TeamSelector.open(p, arena);
        return true;
    }

    @Override
    public List<String> getTabComplete() {
        return new ArrayList<>();
    }
}
