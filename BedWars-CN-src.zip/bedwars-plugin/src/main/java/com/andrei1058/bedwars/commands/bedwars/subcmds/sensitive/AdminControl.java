package com.andrei1058.bedwars.commands.bedwars.subcmds.sensitive;

import com.andrei1058.bedwars.BedWars;
import com.andrei1058.bedwars.api.arena.GameState;
import com.andrei1058.bedwars.api.arena.IArena;
import com.andrei1058.bedwars.api.arena.team.ITeam;
import com.andrei1058.bedwars.api.command.ParentCommand;
import com.andrei1058.bedwars.api.command.SubCommand;
import com.andrei1058.bedwars.arena.Arena;
import com.andrei1058.bedwars.configuration.Permissions;
import net.md_5.bungee.api.chat.ClickEvent;
import org.bukkit.command.CommandSender;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Admin: 房间控制命令
 * /bw admincontrol <arena> end
 * /bw admincontrol <arena> start
 * /bw admincontrol <arena> win <teamName>
 * /bw admincontrol <arena> state <waiting|starting|playing|restarting>
 * /bw admincontrol <arena> event <环节>        一键跳转环节（钻石一/二/三、绿宝石一/二/三、床被破坏、游戏结束）
 * /bw admincontrol <arena> destroybed <队伍>   指定某个队伍的床被破坏
 */
public class AdminControl extends SubCommand {

    private static final String PERM = Permissions.PERMISSION_ALL;

    /** 环节跳转的中文补全列表（显示给管理员选择） */
    private static final List<String> EVENT_KEYS = Arrays.asList(
            "钻石一", "钻石二", "钻石三",
            "绿宝石一", "绿宝石二", "绿宝石三",
            "床被破坏", "游戏结束");

    /** 把用户输入的中文/英文环节名规范化为内部键 */
    private static String normalizeEventKey(String input) {
        switch (input.toLowerCase()) {
            case "钻石一": case "钻石1": case "diamond1": case "diamond-i": case "diamondi": case "钻石i": return "diamond1";
            case "钻石二": case "钻石2": case "diamond2": case "diamond-ii": case "diamondii": return "diamond2";
            case "钻石三": case "钻石3": case "diamond3": case "diamond-iii": case "diamondiii": return "diamond3";
            case "绿宝石一": case "绿宝石1": case "emerald1": case "emerald-i": case "emeraldi": case "绿宝石i": return "emerald1";
            case "绿宝石二": case "绿宝石2": case "emerald2": case "emerald-ii": case "emeraldii": return "emerald2";
            case "绿宝石三": case "绿宝石3": case "emerald3": case "emerald-iii": case "emeraldiii": return "emerald3";
            case "床被破坏": case "床破坏": case "床": case "beds": case "bed": case "beds-destroy": case "bedsdestroyed": return "beds";
            case "游戏结束": case "结束": case "end": case "game-end": case "gameend": return "end";
        }
        return input.toLowerCase();
    }

    public AdminControl(ParentCommand parent, String name) {
        super(parent, name);
        setPriority(20);
        showInList(true);
        setDisplayInfo(com.andrei1058.bedwars.arena.Misc.msgHoverClick(
                "§6 ▪ §7/" + getParent().getName() + " " + getSubCommandName() + " §6<arena> <end|start|win|state|event|destroybed>",
                "§fAdmin 房间控制\n" +
                        "§7end §f- 强制结束比赛\n" +
                        "§7start §f- 强制开始倒计时\n" +
                        "§7win <队伍> §f- 指定队伍获胜\n" +
                        "§7state <状态> §f- 切换到指定阶段\n" +
                        "§7状态: waiting/starting/playing/restarting\n" +
                        "§7event <环节> §f- 一键跳转环节（钻石一/二/三、绿宝石一/二/三、床被破坏、游戏结束）\n" +
                        "§7destroybed <队伍> §f- 指定队伍床被破坏",
                "/" + getParent().getName() + " " + getSubCommandName() + " ",
                ClickEvent.Action.SUGGEST_COMMAND));
        setPermission(PERM);
    }

    @Override
    public boolean execute(String[] args, CommandSender s) {
        if (!(s instanceof Player)) return true;
        Player p = (Player) s;
        if (args.length < 2) {
            p.sendMessage("§c▪ §7用法: §o/" + getParent().getName() + " " + getSubCommandName() + " <arena> <end|start|win|state|event|destroybed> [参数]");
            return true;
        }

        IArena arena = Arena.getArenaByName(args[0]);
        if (arena == null) {
            p.sendMessage("§c▪ §7房间 §f" + args[0] + " §c不存在或未启用");
            return true;
        }

        String action = args[1].toLowerCase();
        switch (action) {
            case "end":
                // 结束房间：把所有玩家传送到大厅，然后直接进入重启环节
                if (arena.getStatus() == GameState.restarting) {
                    p.sendMessage("§e▪ §7该房间已在结算/重置中");
                    return true;
                }
                ((Arena) arena).endToLobbyAndRestart();
                p.sendMessage("§a▪ §7已结束 §f" + arena.getArenaName() + " §7：玩家已送回大厅，正在重置房间");
                return true;

            case "start":
                if (arena.getStatus() != GameState.waiting && arena.getStatus() != GameState.starting) {
                    p.sendMessage("§c▪ §7当前状态不允许开始: " + arena.getStatus());
                    return true;
                }
                arena.changeStatus(GameState.starting);
                p.sendMessage("§a▪ §7已强制开始 §f" + arena.getArenaName());
                return true;

            case "event":
                if (args.length < 3) {
                    p.sendMessage("§c▪ §7用法: /" + getParent().getName() + " " + getSubCommandName() + " " + args[0] + " event <环节>");
                    p.sendMessage("§7可选环节: §e钻石一 §7/ §e钻石二 §7/ §e钻石三 §7/ §e绿宝石一 §7/ §e绿宝石二 §7/ §e绿宝石三 §7/ §e床被破坏 §7/ §e游戏结束");
                    return true;
                }
                if (arena.getStatus() != GameState.playing) {
                    p.sendMessage("§c▪ §7房间当前不是进行中状态（" + arena.getStatus() + "），无法跳转环节");
                    return true;
                }
                String eventKey = normalizeEventKey(args[2]);
                if (!((Arena) arena).forceJumpEvent(eventKey)) {
                    p.sendMessage("§c▪ §7未知环节: " + args[2]);
                    return true;
                }
                p.sendMessage("§a▪ §7已跳转 §f" + arena.getArenaName() + " §7到环节: §e" + args[2]);
                return true;

            case "destroybed":
                if (args.length < 3) {
                    p.sendMessage("§c▪ §7用法: /" + getParent().getName() + " " + getSubCommandName() + " " + args[0] + " destroybed <队伍>");
                    return true;
                }
                if (arena.getStatus() != GameState.playing) {
                    p.sendMessage("§c▪ §7房间当前不是进行中状态（" + arena.getStatus() + "），无法破坏床");
                    return true;
                }
                ITeam bedTeam = matchTeam(arena, p, args[2]);
                if (bedTeam == null) {
                    p.sendMessage("§c▪ §7队伍 §f" + args[2] + " §c不存在。可用队伍: ");
                    for (ITeam t : arena.getTeams()) {
                        p.sendMessage("  §7- " + t.getDisplayName(com.andrei1058.bedwars.api.language.Language.getPlayerLanguage(p)));
                    }
                    return true;
                }
                if (bedTeam.isBedDestroyed()) {
                    p.sendMessage("§e▪ §7队伍 §f" + bedTeam.getDisplayName(com.andrei1058.bedwars.api.language.Language.getPlayerLanguage(p)) + " §7的床已经被破坏了");
                    return true;
                }
                ((Arena) arena).forceTeamBedDestroy(bedTeam);
                p.sendMessage("§a▪ §7已破坏 §f" + bedTeam.getDisplayName(com.andrei1058.bedwars.api.language.Language.getPlayerLanguage(p)) + " §7的床");
                return true;

            case "win":
                if (args.length < 3) {
                    p.sendMessage("§c▪ §7用法: /" + getParent().getName() + " " + getSubCommandName() + " " + args[0] + " win <队伍名>");
                    return true;
                }
                if (arena.getStatus() == GameState.restarting) {
                    p.sendMessage("§e▪ §7该房间已在结算/重置中");
                    return true;
                }
                // 空房间保护：无玩家时不允许结算，直接重置房间，避免卡死在结算状态
                if (arena.getPlayers().isEmpty()) {
                    ((Arena) arena).endToLobbyAndRestart();
                    p.sendMessage("§e▪ §7房间内没有玩家，无法结算胜利，已直接重置房间");
                    return true;
                }
                ITeam winnerTeam = matchTeam(arena, p, args[2]);
                if (winnerTeam == null) {
                    p.sendMessage("§c▪ §7队伍 §f" + args[2] + " §c不存在。可用队伍: ");
                    for (ITeam t : arena.getTeams()) {
                        p.sendMessage("  §7- " + t.getDisplayName(com.andrei1058.bedwars.api.language.Language.getPlayerLanguage(p)));
                    }
                    return true;
                }
                // 空队伍保护：目标队伍无存活成员时拒绝结算，避免空队伍胜利导致房间卡死
                if (winnerTeam.getMembers().isEmpty()) {
                    p.sendMessage("§c▪ §7队伍 §f" + winnerTeam.getDisplayName(com.andrei1058.bedwars.api.language.Language.getPlayerLanguage(p)) + " §c没有存活成员，不能指定为胜利队伍");
                    return true;
                }
                ((Arena) arena).forceEnd(winnerTeam);
                p.sendMessage("§a▪ §7已强制 §f" + winnerTeam.getDisplayName(com.andrei1058.bedwars.api.language.Language.getPlayerLanguage(p)) + " §7获胜");
                return true;

            case "reset":
                // 急救：强制把卡死的房间重置为等待状态（只清内存数据，不碰世界还原）
                if (arena.getStatus() != GameState.restarting) {
                    p.sendMessage("§e▪ §7房间当前状态是 " + arena.getStatus() + "，不是卡死状态，无需重置");
                    return true;
                }
                ((Arena) arena).setStatus(GameState.waiting);
                p.sendMessage("§a▪ §7已重置 §f" + arena.getArenaName() + " §7为等待状态（内存数据已清理）");
                return true;

            case "state":
                if (args.length < 3) {
                    p.sendMessage("§c▪ §7用法: /" + getParent().getName() + " " + getSubCommandName() + " " + args[0] + " state <waiting|starting|playing|restarting>");
                    return true;
                }
                GameState target;
                try {
                    target = GameState.valueOf(args[2].toUpperCase());
                } catch (IllegalArgumentException e) {
                    p.sendMessage("§c▪ §7无效状态: " + args[2]);
                    return true;
                }
                arena.changeStatus(target);
                p.sendMessage("§a▪ §7已切换 §f" + arena.getArenaName() + " §7到 §e" + target);
                return true;

            default:
                p.sendMessage("§c▪ §7未知操作: " + action);
                return true;
        }
    }

    /**
     * 匹配队伍：优先队伍英文名，其次中文显示名。
     */
    private static ITeam matchTeam(IArena arena, Player p, String input) {
        if (input == null) return null;
        for (ITeam t : arena.getTeams()) {
            if (t.getName().equalsIgnoreCase(input)) {
                return t;
            }
        }
        for (ITeam t : arena.getTeams()) {
            if (t.getDisplayName(com.andrei1058.bedwars.api.language.Language.getPlayerLanguage(p)).equalsIgnoreCase(input)) {
                return t;
            }
        }
        return null;
    }

    /** 返回该房间队伍的中文显示名列表（用于 Tab 补全，采用服务器默认语言） */
    private static List<String> teamDisplayNames(IArena arena) {
        List<String> teams = new ArrayList<>();
        com.andrei1058.bedwars.api.language.Language lang =
                com.andrei1058.bedwars.api.language.Language.getDefaultLanguage();
        for (ITeam t : arena.getTeams()) {
            String display = t.getDisplayName(lang);
            teams.add(display);
            if (!display.equals(t.getName())) {
                teams.add(t.getName());
            }
        }
        return teams;
    }

    @Override
    public List<String> getTabComplete() {
        List<String> tab = new ArrayList<>();
        for (IArena a : Arena.getArenas()) {
            tab.add(a.getArenaName());
        }
        return tab;
    }

    @Override
    public List<String> getTabComplete(String[] args) {
        // args[0]=admincontrol, args[1]=房间, args[2]=操作, args[3]=参数
        if (args.length == 2) return getTabComplete();
        if (args.length == 3) return Arrays.asList("end", "start", "win", "state", "reset", "event", "destroybed");
        if (args.length == 4) {
            String action = args[2].toLowerCase();
            if (action.equals("win") || action.equals("destroybed")) {
                IArena arena = Arena.getArenaByName(args[1]);
                if (arena == null) return null;
                return teamDisplayNames(arena);
            }
            if (action.equals("event")) {
                return EVENT_KEYS;
            }
            if (action.equals("state")) {
                return Arrays.asList("waiting", "starting", "playing", "restarting");
            }
        }
        return null;
    }

    @Override
    public boolean canSee(CommandSender s, com.andrei1058.bedwars.api.BedWars api) {
        if (s instanceof ConsoleCommandSender) return false;
        return hasPermission(s);
    }
}
