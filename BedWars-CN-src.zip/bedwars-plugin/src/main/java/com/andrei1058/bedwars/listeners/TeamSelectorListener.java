package com.andrei1058.bedwars.listeners;

import com.andrei1058.bedwars.api.arena.team.ITeam;
import com.andrei1058.bedwars.api.language.Language;
import com.andrei1058.bedwars.api.sidebar.ISidebar;
import com.andrei1058.bedwars.arena.TeamSelector;
import com.andrei1058.bedwars.sidebar.SidebarService;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;

public class TeamSelectorListener implements Listener {

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player)) return;
        Player p = (Player) e.getWhoClicked();
        TeamSelector.Session s = TeamSelector.sessions.get(p.getUniqueId());
        if (s == null) return;
        e.setCancelled(true);
        if (e.getCurrentItem() == null || e.getCurrentItem().getType() == Material.AIR) return;
        ITeam team = s.slots.get(e.getRawSlot());
        if (team == null) return;
        Language lang = Language.getPlayerLanguage(p);
        if (team.isMember(p)) {
            p.closeInventory();
            return;
        }
        if (team.getMembers().size() >= s.arena.getMaxInTeam()) {
            p.sendMessage(lang.m("team-selector.full"));
            return;
        }
        ITeam old = s.arena.getTeam(p);
        if (old != null && old != team) {
            old.getMembers().removeIf(m -> m != null && m.getUniqueId().equals(p.getUniqueId()));
        }
        // 保险：从所有其它队伍移除该玩家，防止任何残留导致 arena.getTeam() 返回旧队伍
        // （Tab 前缀 / Tab 底部"你所在队伍" / 侧边栏"你"标记都基于 getTeam 判断，
        //   残留会让界面显示成旧队伍）
        for (ITeam t : s.arena.getTeams()) {
            if (t != team) {
                t.getMembers().removeIf(m -> m != null && m.getUniqueId().equals(p.getUniqueId()));
            }
        }
        team.addPlayers(p);
        // give the player the dyed leather armor of the chosen team right away
        // so they can see their team before the game starts
        if (team instanceof com.andrei1058.bedwars.arena.team.BedWarsTeam) {
            ((com.andrei1058.bedwars.arena.team.BedWarsTeam) team).sendArmor(p);
        }
        // refresh the TAB prefix/footer so every player's view shows the new team
        // (otherwise the prefix keeps showing the old team while the footer shows the new one)
        for (Player viewer : s.arena.getPlayers()) {
            ISidebar sb = SidebarService.getInstance().getSidebar(viewer);
            if (sb != null) sb.giveUpdateTabFormat(viewer, true, null);
        }
        for (Player viewer : s.arena.getSpectators()) {
            ISidebar sb = SidebarService.getInstance().getSidebar(viewer);
            if (sb != null) sb.giveUpdateTabFormat(viewer, true, null);
        }
        p.sendMessage(lang.m("team-selector.selected").replace("{team}", ChatColor.stripColor(team.getDisplayName(lang))));
        p.closeInventory();
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        TeamSelector.sessions.remove(e.getPlayer().getUniqueId());
    }
}
