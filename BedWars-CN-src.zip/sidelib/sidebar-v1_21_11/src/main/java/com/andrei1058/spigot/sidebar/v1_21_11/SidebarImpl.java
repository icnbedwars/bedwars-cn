package com.andrei1058.spigot.sidebar.v1_21_11;

import com.andrei1058.spigot.sidebar.*;
import io.papermc.paper.scoreboard.numbers.NumberFormat;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Score;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

import java.util.Objects;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Collection;

/**
 * Minecraft 1.21.11 implementation of the sidebar library.
 * <p>
 * Modern Paper runtimes (1.21.x) no longer expose versioned CraftBukkit
 * packages (org.bukkit.craftbukkit.v1_XX_RX) and the obfuscated NMS mappings
 * changed repeatedly, so this implementation is built entirely on the stable
 * Bukkit Scoreboard API plus Paper's {@code Player#sendPlayerListHeaderAndFooter}.
 * No NMS classes are referenced at all.
 */
@SuppressWarnings("unused")
public class SidebarImpl extends WrappedSidebar {

    private Scoreboard scoreboard;

    public SidebarImpl(@NotNull SidebarLine title, @NotNull Collection<SidebarLine> lines, Collection<PlaceholderProvider> placeholderProvider) {
        super(title, lines, placeholderProvider);
    }

    /**
     * Lazily initialised scoreboard.
     * <p>
     * IMPORTANT: the {@link WrappedSidebar} super constructor calls back into
     * this class (createObjective / createScore / refreshContent) before the
     * subclass constructor body runs, so the field cannot be assigned there.
     * Creating the scoreboard on first access keeps those callbacks safe.
     */
    public Scoreboard getScoreboard() {
        if (scoreboard == null) {
            scoreboard = Bukkit.getScoreboardManager().getNewScoreboard();
        }
        return scoreboard;
    }

    /**
     * First receiver, or {@code null} when the sidebar has no attached players yet.
     * The receivers queue is empty during construction, so {@code getFirst()} would throw.
     */
    public Player firstReceiver() {
        return getReceivers().isEmpty() ? null : getReceivers().peek();
    }

    public ScoreLine createScore(SidebarLine line, int score, String color) {
        return new ScoreLineImpl(this, line, score, color);
    }

    public SidebarObjective createObjective(String name, boolean health, SidebarLine title, int type) {
        return new SidebarObjectiveImpl(this, name, health, title, type);
    }

    /**
     * Update the below-name health score of the given player.
     */
    public void setHealthScore(String playerName, int health) {
        try {
            Objective healthObjective = getScoreboard().getObjective("health");
            if (healthObjective == null) {
                healthObjective = getScoreboard().getObjective("health2");
            }
            if (healthObjective == null) {
                return;
            }
            Score score = healthObjective.getScore(playerName);
            score.setScore(health);
        } catch (IllegalStateException ignored) {
            // 1.21 中 health 判据的目标分数为只读时静默跳过，避免刷屏
        }
    }

    /**
     * Objective backed by the Bukkit scoreboard API.
     */
    protected class SidebarObjectiveImpl implements SidebarObjective {

        private final SidebarImpl sidebar;
        private final String name;
        private final boolean health;
        private final int type;
        private SidebarLine displayName;
        private String lastTitle;

        public SidebarObjectiveImpl(SidebarImpl sidebar, String name, boolean health, SidebarLine displayName, int type) {
            this.sidebar = sidebar;
            this.name = name;
            this.health = health;
            this.type = type;
            this.displayName = displayName;
        }

        private Objective ensureObjective() {
            Objective objective = sidebar.getScoreboard().getObjective(name);
            if (objective == null) {
                // 1.21 起 "health" 判据的目标分数是只读的（ObjectiveCriteria.isReadOnly），
                // 插件侧无法写入。统一改用可写的 "dummy" 判据，由 setHealthScore 手动刷新血量分数。
                String criteria = "dummy";
                String titleText = displayName.getTrimReplacePlaceholders(
                        firstReceiver(),
                        64,
                        sidebar.getPlaceholders()
                );
                objective = sidebar.getScoreboard().registerNewObjective(name, criteria, titleText);
                if (type == 1) {
                    objective.setDisplaySlot(DisplaySlot.SIDEBAR);
                } else if (type == 2) {
                    objective.setDisplaySlot(DisplaySlot.BELOW_NAME);
                }
            }
            return objective;
        }

        @Override
        public void setTitle(SidebarLine title) {
            this.displayName = title;
        }

        @Override
        public SidebarLine getTitle() {
            return displayName;
        }

        @Override
        public void sendCreate(Player player) {
            ensureObjective();
            // Attach the whole scoreboard (objective, teams, scores) to the player.
            player.setScoreboard(sidebar.getScoreboard());
        }

        @Override
        public void sendUpdate() {
            Objective objective = sidebar.getScoreboard().getObjective(name);
            if (objective == null) {
                return;
            }
            String newTitle = displayName.getTrimReplacePlaceholders(
                    firstReceiver(),
                    64,
                    sidebar.getPlaceholders()
            );
            if (!newTitle.equals(objective.getDisplayName())) {
                objective.setDisplayName(newTitle);
            }
        }

        @Override
        public void sendRemove(Player player) {
            Objective objective = sidebar.getScoreboard().getObjective(name);
            if (objective != null) {
                objective.unregister();
            }
        }

        @Override
        public String getName() {
            return name;
        }

        @Override
        public boolean refreshTitle() {
            String newTitle = displayName.getTrimReplacePlaceholders(
                    firstReceiver(),
                    64,
                    sidebar.getPlaceholders()
            );
            if (newTitle.equals(lastTitle)) {
                return false;
            }
            lastTitle = newTitle;
            Objective objective = sidebar.getScoreboard().getObjective(name);
            if (objective != null) {
                objective.setDisplayName(newTitle);
            }
            return true;
        }
    }

    /**
     * Score line backed by a Bukkit team (prefix + suffix) and a score entry.
     * <p>
     * Each line uses its color code as the scoreboard entry (invisible text) and
     * puts the actual line content into the team suffix, exactly like the legacy
     * NMS implementation did with scoreboard packets.
     */
    public class ScoreLineImpl implements ScoreLine, Comparable<ScoreLine> {

        private final SidebarImpl sidebar;
        private int score;
        private SidebarLine text;
        private final String color;
        private Team team;
        private String lastContent;
        private String lastScore;

        public ScoreLineImpl(SidebarImpl sidebar, @NotNull SidebarLine text, int score, @NotNull String color) {
            this.sidebar = sidebar;
            this.score = score;
            this.text = text;
            this.color = color;
        }

        private Team ensureTeam() {
            if (team == null) {
                team = sidebar.getScoreboard().getTeam(color);
                if (team == null) {
                    team = sidebar.getScoreboard().registerNewTeam(color);
                    team.setPrefix(" ");
                }
                if (!team.getEntries().contains(color)) {
                    team.addEntry(color);
                }
            }
            return team;
        }

        private org.bukkit.scoreboard.Score getBukkitScore() {
            Objective objective = sidebar.getScoreboard().getObjective(sidebar.getSidebarObjective().getName());
            if (objective == null) {
                return null;
            }
            return objective.getScore(color);
        }

        @Override
        public SidebarLine getLine() {
            return text;
        }

        @Override
        public void setLine(SidebarLine line) {
            this.text = line;
        }

        @Override
        public int getScoreAmount() {
            return score;
        }

        @Override
        public void setScoreAmount(int score) {
            this.score = score;
            org.bukkit.scoreboard.Score bukkitScore = getBukkitScore();
            if (bukkitScore != null) {
                bukkitScore.setScore(score);
            }
        }

        @Override
        public void sendCreateToAllReceivers() {
            ensureTeam();
            org.bukkit.scoreboard.Score bukkitScore = getBukkitScore();
            if (bukkitScore != null) {
                bukkitScore.setScore(score);
            }
            applyContent(null, null);
        }

        @Override
        public void sendCreate(Player player) {
            // The whole scoreboard is attached once by the objective; nothing else needed per player.
            sendCreateToAllReceivers();
        }

        @Override
        public boolean setContent(SidebarLine line) {
            this.text = line;
            return refreshContent();
        }

        @Override
        public void sendUpdateToAllReceivers() {
            applyContent(null, null);
        }

        @Override
        public void sendUpdate(Player player) {
            applyContent(null, null);
        }

        @Override
        public void sendRemoveToAllReceivers() {
            removeLine();
        }

        @Override
        public void sendRemove(Player player) {
            removeLine();
        }

        private void removeLine() {
            if (sidebar.getScoreboard() != null) {
                try {
                    sidebar.getScoreboard().resetScores(color);
                } catch (IllegalArgumentException ignored) {
                }
            }
            if (team != null) {
                try {
                    team.unregister();
                } catch (IllegalStateException ignored) {
                }
                team = null;
            }
        }

        @Override
        public String getColor() {
            return color;
        }

        @Override
        public boolean refreshContent() {
            String content = text.getTrimReplacePlaceholders(
                    firstReceiver(),
                    null,
                    sidebar.getPlaceholders()
            );
            String scoreText = text.getTrimReplacePlaceholdersScore(
                    firstReceiver(),
                    null,
                    sidebar.getPlaceholders()
            );
            if (content.equals(lastContent) && Objects.equals(scoreText, lastScore)) {
                return false;
            }
            lastContent = content;
            lastScore = scoreText;
            applyContent(content, scoreText);
            return true;
        }

        private void applyContent(@Nullable String content, @Nullable String scoreText) {
            if (content == null) {
                content = text.getTrimReplacePlaceholders(
                        firstReceiver(),
                        null,
                        sidebar.getPlaceholders()
                );
            }
            if (scoreText == null) {
                scoreText = text.getTrimReplacePlaceholdersScore(
                        firstReceiver(),
                        null,
                        sidebar.getPlaceholders()
                );
            }
            Team t = ensureTeam();
            if (content.length() > 62) {
                content = content.substring(0, 62);
            }
            if (!content.equals(t.getSuffix())) {
                t.setSuffix(content);
            }
            org.bukkit.scoreboard.Score bukkitScore = getBukkitScore();
            if (bukkitScore != null) {
                if (scoreText != null && !scoreText.isEmpty()) {
                    bukkitScore.numberFormat(NumberFormat.fixed(Component.text(scoreText)));
                } else {
                    bukkitScore.numberFormat(NumberFormat.blank());
                }
            }
        }

        @Override
        public int compareTo(ScoreLine o) {
            return Integer.compare(o.getScoreAmount(), this.getScoreAmount());
        }
    }
}
