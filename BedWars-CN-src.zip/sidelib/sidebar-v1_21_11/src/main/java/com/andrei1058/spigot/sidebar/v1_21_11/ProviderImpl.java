package com.andrei1058.spigot.sidebar.v1_21_11;

import com.andrei1058.spigot.sidebar.*;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Collection;

/**
 * Minecraft 1.21.11 provider built on the Bukkit Scoreboard API and the
 * Paper player-list API. No NMS/CraftBukkit-versioned classes are used.
 */
@SuppressWarnings("unused")
public class ProviderImpl extends SidebarProvider {

    @Override
    public Sidebar createSidebar(SidebarLine title, Collection<SidebarLine> lines, Collection<PlaceholderProvider> placeholderProviders) {
        return new SidebarImpl(title, lines, placeholderProviders);
    }

    @Override
    public SidebarObjective createObjective(@NotNull WrappedSidebar sidebar, String name, boolean health, SidebarLine title, int type) {
        return ((SidebarImpl) sidebar).createObjective(name, health, title, type);
    }

    @Override
    public ScoreLine createScoreLine(WrappedSidebar sidebar, SidebarLine line, int score, String color) {
        return ((SidebarImpl) sidebar).createScore(line, score, color);
    }

    @Override
    public void sendScore(@NotNull WrappedSidebar sidebar, String playerName, int score) {
        if (sidebar.getHealthObjective() == null) {
            return;
        }
        ((SidebarImpl) sidebar).setHealthScore(playerName, score);
    }

    @Override
    public VersionedTabGroup createPlayerTab(
            WrappedSidebar sidebar,
            String identifier,
            SidebarLine prefix,
            SidebarLine suffix,
            PlayerTab.PushingRule pushingRule,
            PlayerTab.NameTagVisibility nameTagVisibility,
            @Nullable Collection<PlaceholderProvider> placeholders
    ) {
        return new PlayerListImpl(sidebar, identifier, prefix, suffix, pushingRule, nameTagVisibility, placeholders);
    }

    @Override
    public void sendHeaderFooter(Player player, String header, String footer) {
        // Parse & color codes so the tab header/footer renders colors instead of literal &x.
        LegacyComponentSerializer legacy = LegacyComponentSerializer.legacyAmpersand();
        player.sendPlayerListHeaderAndFooter(
                legacy.deserialize(header == null ? "" : header),
                legacy.deserialize(footer == null ? "" : footer)
        );
    }
}
