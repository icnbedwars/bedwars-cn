package com.andrei1058.spigot.sidebar.v1_21_11;

import com.andrei1058.spigot.sidebar.*;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.Team;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Collection;
import java.util.Objects;

/**
 * Tab-list team backed by the Bukkit scoreboard team API.
 * <p>
 * The team is registered on the shared sidebar scoreboard, so every player
 * who has been attached to that scoreboard sees the tab formatting.
 */
@SuppressWarnings("unused")
public class PlayerListImpl implements VersionedTabGroup {

    private final WrappedSidebar sidebar;
    private final String identifier;
    private final SidebarLine prefix;
    private final SidebarLine suffix;
    private PlayerTab.PushingRule pushingRule;
    private PlayerTab.NameTagVisibility nameTagVisibility;
    private final Collection<PlaceholderProvider> placeholders;
    private @Nullable Player subject;

    private String lastPrefix;
    private String lastSuffix;

    public PlayerListImpl(
            @NotNull WrappedSidebar sidebar,
            String identifier,
            SidebarLine prefix,
            SidebarLine suffix,
            PlayerTab.PushingRule pushingRule,
            PlayerTab.NameTagVisibility nameTagVisibility,
            @Nullable Collection<PlaceholderProvider> placeholders
    ) {
        this.sidebar = sidebar;
        this.identifier = identifier;
        this.prefix = prefix;
        this.suffix = suffix;
        this.pushingRule = pushingRule;
        this.nameTagVisibility = nameTagVisibility;
        this.placeholders = placeholders;
    }

    private Team ensureTeam() {
        SidebarImpl impl = (SidebarImpl) sidebar;
        Team team = impl.getScoreboard().getTeam(identifier);
        if (team == null) {
            team = impl.getScoreboard().registerNewTeam(identifier);
            team.setOption(Team.Option.COLLISION_RULE, toBukkitCollision(pushingRule));
            team.setOption(Team.Option.NAME_TAG_VISIBILITY, toBukkitVisibility(nameTagVisibility));
        }
        return team;
    }

    private Team.OptionStatus toBukkitCollision(PlayerTab.PushingRule rule) {
        switch (rule) {
            case ALWAYS:
                return Team.OptionStatus.ALWAYS;
            case NEVER:
                return Team.OptionStatus.NEVER;
            case PUSH_OTHER_TEAMS:
                return Team.OptionStatus.FOR_OTHER_TEAMS;
            case PUSH_OWN_TEAM:
                return Team.OptionStatus.FOR_OWN_TEAM;
        }
        return Team.OptionStatus.ALWAYS;
    }

    private Team.OptionStatus toBukkitVisibility(PlayerTab.NameTagVisibility visibility) {
        switch (visibility) {
            case ALWAYS:
                return Team.OptionStatus.ALWAYS;
            case NEVER:
                return Team.OptionStatus.NEVER;
            case HIDE_FOR_OTHER_TEAMS:
                return Team.OptionStatus.FOR_OTHER_TEAMS;
            case HIDE_FOR_OWN_TEAM:
                return Team.OptionStatus.FOR_OWN_TEAM;
        }
        return Team.OptionStatus.ALWAYS;
    }

    @Override
    public void sendCreateToPlayer(Player player) {
        applyContent(false);
        // Receivers see the team through the shared scoreboard once attached.
    }

    @Override
    public void sendUserCreateToReceivers(@NotNull Player player) {
        Team team = ensureTeam();
        if (!team.hasEntry(player.getName())) {
            team.addEntry(player.getName());
        }
        // Tab 列表显示名：1.13+ 客户端 Tab 列表不渲染 team prefix 文本，
        // 必须通过 playerListName 把 prefix+名字+suffix 显示出来，否则 Tab 上看不到队伍。
        updateTabListName(player.getName());
    }

    @Override
    public void sendUpdateToReceivers() {
        applyContent(false);
    }

    @Override
    public void sendRemoveToReceivers() {
        SidebarImpl impl = (SidebarImpl) sidebar;
        try {
            Team team = impl.getScoreboard().getTeam(identifier);
            if (team != null) {
                for (String entry : team.getEntries()) {
                    resetTabListName(entry);
                }
                team.unregister();
            }
        } catch (IllegalStateException ignored) {
            // team 已被注销（例如整局结束时 scoreboard 被重建），无需重复清理
        }
    }

    /**
     * 把前缀中的"第一个有效颜色码"映射为 Bukkit ChatColor。
     * 会跳过灰色（&7）、深灰（&8）与重置（&r）以及纯格式码（k/l/m/n/o）——
     * 它们通常是前缀的默认打底色，真正表达队伍身份的颜色是后面的彩色码（如 §c 红 / §e 黄）。
     * 用于设置头顶名牌颜色：玩家在游戏内看到其他玩家名字显示对应队伍色。
     *
     * @return 匹配的 ChatColor，若前缀没有有效颜色码则返回 null（保持原样）
     */
    private @Nullable ChatColor extractTeamColor(@Nullable String prefix) {
        if (prefix == null) return null;
        int idx = prefix.indexOf('§');
        while (idx >= 0 && idx + 1 < prefix.length()) {
            char code = prefix.charAt(idx + 1);
            if (code == '7' || code == '8' || code == 'r'
                    || code == 'k' || code == 'l' || code == 'm' || code == 'n' || code == 'o') {
                // 跳过灰色系与纯格式码，继续找真正的颜色码
                idx = prefix.indexOf('§', idx + 2);
                continue;
            }
            ChatColor color = ChatColor.getByChar(code);
            if (color != null && color.isColor()) {
                return color;
            }
            idx = prefix.indexOf('§', idx + 2);
        }
        return null;
    }

    @Override
    public boolean refreshContent() {
        return applyContent(true);
    }

    private boolean applyContent(boolean checkOnly) {
        Player papiSubject = getSubject();
        String newPrefix = prefix.getTrimReplacePlaceholders(papiSubject, 64, placeholders);
        String newSuffix = suffix.getTrimReplacePlaceholders(papiSubject, 64, placeholders);
        if (newPrefix.length() > 62) {
            newPrefix = newPrefix.substring(0, 62);
        }
        if (newSuffix.length() > 62) {
            newSuffix = newSuffix.substring(0, 62);
        }
        boolean changed = !Objects.equals(newPrefix, lastPrefix) || !Objects.equals(newSuffix, lastSuffix);
        if (checkOnly) {
            return changed;
        }
        if (!changed) {
            return false;
        }
        Team team = ensureTeam();
        if (!newPrefix.equals(team.getPrefix())) {
            team.setPrefix(newPrefix);
        }
        if (!newSuffix.equals(team.getSuffix())) {
            team.setSuffix(newSuffix);
        }
        // 同步头顶名牌颜色：取前缀中的第一个颜色码，让玩家名显示为队伍色。
        // 若前缀没有颜色码（纯文本前缀），保持原样不做修改。
        ChatColor color = extractTeamColor(newPrefix);
        if (color != null && color != team.getColor()) {
            try {
                team.setColor(color);
            } catch (Exception ignored) {
                // 个别服务端版本可能不允许 RESET，忽略即可
            }
        }
        // Tab 列表显示名同步刷新（prefix+名字+suffix）
        for (String entry : team.getEntries()) {
            updateTabListName(entry);
        }
        lastPrefix = newPrefix;
        lastSuffix = newSuffix;
        return true;
    }

    /**
     * 更新某名玩家的 Tab 列表显示名 = 队伍前缀 + 玩家名 + 后缀。
     * 1.13+ 客户端 Tab 列表只显示 playerListName（着 team color），不渲染 team prefix，
     * 因此必须显式设置显示名，Tab 上才能看到 [队伍名]。
     */
    private void updateTabListName(String entryName) {
        Player target = Bukkit.getPlayerExact(entryName);
        if (target == null) return;
        String name = target.getName();
        String display = (lastPrefix == null ? "" : lastPrefix) + name + (lastSuffix == null ? "" : lastSuffix);
        try {
            target.playerListName(LegacyComponentSerializer.legacySection().deserialize(display));
        } catch (Exception ignored) {
            // 个别非 Paper 服务端没有 playerListName API，静默降级（Tab 仅显示名字）
        }
    }

    /**
     * 重置某名玩家的 Tab 列表显示名，恢复默认（仅玩家名）。
     */
    private void resetTabListName(String entryName) {
        Player target = Bukkit.getPlayerExact(entryName);
        if (target == null) return;
        try {
            target.playerListName(null);
        } catch (Exception ignored) {
        }
    }

    @Override
    public void add(@NotNull Player player) {
        Team team = ensureTeam();
        if (!team.hasEntry(player.getName())) {
            team.addEntry(player.getName());
        }
        updateTabListName(player.getName());
    }

    @Override
    public void remove(@NotNull Player player) {
        SidebarImpl impl = (SidebarImpl) sidebar;
        Team team = impl.getScoreboard().getTeam(identifier);
        if (team != null) {
            resetTabListName(player.getName());
            team.removeEntry(player.getName());
        }
    }

    @Override
    public void setSubject(@Nullable Player player) {
        this.subject = player;
    }

    @Override
    public @Nullable Player getSubject() {
        return subject;
    }

    @Override
    public void setPushingRule(@SuppressWarnings("unused") PushingRule rule) {
        this.pushingRule = rule;
        Team team = ((SidebarImpl) sidebar).getScoreboard().getTeam(identifier);
        if (team != null) {
            team.setOption(Team.Option.COLLISION_RULE, toBukkitCollision(rule));
        }
    }

    @Override
    public void setNameTagVisibility(@SuppressWarnings("unused") NameTagVisibility nameTagVisibility) {
        this.nameTagVisibility = nameTagVisibility;
        Team team = ((SidebarImpl) sidebar).getScoreboard().getTeam(identifier);
        if (team != null) {
            team.setOption(Team.Option.NAME_TAG_VISIBILITY, toBukkitVisibility(nameTagVisibility));
        }
    }

    @Override
    public String getIdentifier() {
        return identifier;
    }
}
