@echo off
REM BedWars-CN 一键编译脚本（Windows）
REM 需要：JDK 17 或更高、Maven 3.8+
REM 用法：在源码根目录双击或执行 build.bat
REM 注意：不要直接 mvn clean install！sidebar-base 是自定义库，必须先编译 sidelib；
REM       bungeecord-chat 在 hub.spigotmc.org（国内网络访问慢），脚本用附带 jar 自动安装。

setlocal
set ROOT=%~dp0
set M2REPO=%USERPROFILE%\.m2\repository

echo ========== [0/3] 检查离线依赖（bungeecord-chat 1.8-SNAPSHOT） ==========
if not exist "%M2REPO%\net\md-5\bungeecord-chat\1.8-SNAPSHOT\" (
    echo 本地仓库缺少 bungeecord-chat 1.8-SNAPSHOT，正在用附带 jar 安装...
    call mvn install:install-file -Dfile="%ROOT%lib\bungeecord-chat-1.8-SNAPSHOT.jar" -DgroupId=net.md-5 -DartifactId=bungeecord-chat -Dversion=1.8-SNAPSHOT -Dpackaging=jar
    if errorlevel 1 goto :fail
) else (
    echo bungeecord-chat 1.8-SNAPSHOT 已存在，跳过。
)

echo ========== [1/3] 编译并安装 sidelib（sidebar 库） ==========
cd /d "%ROOT%sidelib"
call mvn install -DskipTests
if errorlevel 1 goto :fail

echo ========== [2/3] 编译 BedWars-CN 插件 ==========
cd /d "%ROOT%"
call mvn package -pl bedwars-plugin -am -DskipTests
if errorlevel 1 goto :fail

echo.
echo ========== 编译完成 ==========
echo 插件产物: %ROOT%bedwars-plugin\target\bedwars-plugin-26.1.jar
echo 改名为 BedWars-CN.jar 放入服务器的 plugins\ 目录即可。
pause
exit /b 0

:fail
echo.
echo 编译失败，请查看上方错误信息。
pause
exit /b 1
