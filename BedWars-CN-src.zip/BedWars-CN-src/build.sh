#!/bin/bash
# BedWars-CN 一键编译脚本（Linux / macOS）
# 需要：JDK 17 或更高、Maven 3.8+
# 用法：在源码根目录执行 ./build.sh
# 注意：不要直接 mvn clean install！sidebar-base 是自定义库，必须先编译 sidelib；
#       bungeecord-chat 在 hub.spigotmc.org（网络访问慢），脚本用附带 jar 自动安装。

set -e
ROOT="$(cd "$(dirname "$0")" && pwd)"
M2REPO="${HOME}/.m2/repository"

echo "========== [0/3] 检查离线依赖（bungeecord-chat 1.8-SNAPSHOT） =========="
if [ ! -d "$M2REPO/net/md-5/bungeecord-chat/1.8-SNAPSHOT" ]; then
    echo "本地仓库缺少 bungeecord-chat 1.8-SNAPSHOT，正在用附带 jar 安装..."
    mvn install:install-file -Dfile="$ROOT/lib/bungeecord-chat-1.8-SNAPSHOT.jar" \
        -DgroupId=net.md-5 -DartifactId=bungeecord-chat -Dversion=1.8-SNAPSHOT -Dpackaging=jar
else
    echo "bungeecord-chat 1.8-SNAPSHOT 已存在，跳过。"
fi

echo "========== [1/3] 编译并安装 sidelib（sidebar 库） =========="
cd "$ROOT/sidelib"
mvn install -DskipTests

echo "========== [2/3] 编译 BedWars-CN 插件 =========="
cd "$ROOT"
mvn package -pl bedwars-plugin -am -DskipTests

echo ""
echo "========== 编译完成 =========="
echo "插件产物: $ROOT/bedwars-plugin/target/bedwars-plugin-26.1.jar"
echo "改名为 BedWars-CN.jar 放入服务器的 plugins/ 目录即可。"
