# BedWars-CN 源码编译说明

BedWars-CN（for BedWars1058，Paper 1.21.11 汉化增强分支）完整可编译源码。
结构与原版 BedWars1058 仓库一致：根目录就是插件工程（根 pom.xml 在顶层），另附 sidebar 库（sidelib/）。

## 环境要求

- JDK 17 或更高（编译目标为 Java 11，老版本也能跑）
- Maven 3.8+
- 需要联网（首次编译会从 Maven 中央仓库 / codemc / spigotmc 拉依赖）

## 编译（一定要用脚本，不要直接 mvn clean install）

**Windows**

```
build.bat
```

**Linux / macOS**

```bash
./build.sh
```

脚本做了三步：

0. 检查 `bungeecord-chat 1.8-SNAPSHOT` 是否在本地仓库，缺则用 `lib/` 里的附带 jar 自动安装
   （这个依赖只在 hub.spigotmc.org 上有，国内网络经常拉不到）
1. 先编译 sidelib（sidebar 库，版本 24.2，含 Tab 队伍显示修复）并 `mvn install` 到本地仓库
   （**sidebar-base 是自定义库，公网仓库没有**，直接 mvn 编译必然报 "Could not find artifact ... sidebar-base:24.2"）
2. 再编译根工程的 bedwars-plugin 模块（`-pl bedwars-plugin -am`，自动带上 bedwars-api、versionsupport_v1_21_11 等依赖模块）

## 产物

```
bedwars-plugin/target/bedwars-plugin-26.1.jar
```

改名为 `BedWars-CN.jar` 放进服务器 `plugins/` 目录即可（Paper 1.21.11）。

## 目录结构（原版样式）

- `pom.xml` —— 根工程 pom（版本 26.1），聚合所有模块
- `bedwars-api/` —— API 模块
- `bedwars-plugin/` —— 插件主模块（产物所在）
- `versionsupport_*/` —— 各版本服务端支持模块（含 v1_21_11）
- `resetadapter_*/` —— 地图重置适配模块
- `sidelib/` —— sidebar 库（sidebar-base + sidebar-v1_21_11 等，版本 24.2，含 Tab 队伍显示修复，必须先 install）
- `lib/bungeecord-chat-1.8-SNAPSHOT.jar` —— 离线依赖，脚本自动安装
- `build.sh` / `build.bat` —— 一键编译脚本

## 常见报错对照

| 报错 | 原因 | 解决 |
|---|---|---|
| Could not find artifact com.andrei1058.spigot.sidebar:sidebar-base:jar:24.2 | 没先编译 sidelib | 用 build.bat / build.sh，或手动 `cd sidelib && mvn install -DskipTests` |
| Could not find artifact net.md-5:bungeecord-chat:jar:1.8-SNAPSHOT | hub.spigotmc.org 访问不到 | 脚本会自动用 lib/ 的 jar 安装；手动跑需先 install-file |

## 手动编译（等价命令）

```bash
# 0. 可选：离线依赖
mvn install:install-file -Dfile=lib/bungeecord-chat-1.8-SNAPSHOT.jar -DgroupId=net.md-5 -DartifactId=bungeecord-chat -Dversion=1.8-SNAPSHOT -Dpackaging=jar

# 1. sidelib 装到本地仓库
cd sidelib
mvn install -DskipTests

# 2. 编译插件（在根目录）
cd ..
mvn package -pl bedwars-plugin -am -DskipTests
```

## 离线编译（依赖已在本机仓库时）

给所有 mvn 命令加 `-o` 参数即可（如 `mvn install -DskipTests -o`）。
