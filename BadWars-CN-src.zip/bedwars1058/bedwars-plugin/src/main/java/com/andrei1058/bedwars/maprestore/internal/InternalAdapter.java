/*
 * BedWars1058 - A bed wars mini-game.
 * Copyright (C) 2021 Andrei Dascălu
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 * Contact e-mail: andrew.dascalu@gmail.com
 */

package com.andrei1058.bedwars.maprestore.internal;

import com.andrei1058.bedwars.BedWars;
import com.andrei1058.bedwars.api.arena.IArena;
import com.andrei1058.bedwars.api.configuration.ConfigPath;
import com.andrei1058.bedwars.api.server.ISetupSession;
import com.andrei1058.bedwars.api.server.RestoreAdapter;
import com.andrei1058.bedwars.api.server.ServerType;
import com.andrei1058.bedwars.api.util.FileUtil;
import com.andrei1058.bedwars.api.util.ZipFileUtil;
import com.andrei1058.bedwars.arena.Arena;
import com.andrei1058.bedwars.arena.VoidChunkGenerator;
import com.andrei1058.bedwars.maprestore.internal.files.WorldZipper;
import org.apache.commons.io.FileUtils;
import org.bukkit.*;
import org.bukkit.plugin.Plugin;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import static com.andrei1058.bedwars.BedWars.config;
import static com.andrei1058.bedwars.BedWars.plugin;

@SuppressWarnings("CallToPrintStackTrace")
public class InternalAdapter extends RestoreAdapter {

    public static File backupFolder = new File(BedWars.plugin.getDataFolder() + "/Cache");
    public InternalAdapter(Plugin plugin) {
        super(plugin);
    }

    @Override
    public void onEnable(IArena a) {
        Bukkit.getScheduler().runTask(getOwner(), () -> {
            if (Bukkit.getWorld(a.getWorldName()) != null) {
                Bukkit.getScheduler().runTask(getOwner(), () -> {
                    World w = Bukkit.getWorld(a.getWorldName());
                    a.init(w);
                });
                return;
            }
            Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
                File bf = new File(backupFolder, a.getArenaName() + ".zip");
                File target = new File(Bukkit.getWorldContainer(), a.getWorldName());

                // 升级安全：删除前先把现有世界复制到临时回滚目录，恢复失败时还原，避免存档丢失
                File rollbackDir = null;
                if (target.exists()) {
                    rollbackDir = new File(Bukkit.getWorldContainer(), a.getWorldName() + "_rollback_" + System.currentTimeMillis());
                    try {
                        FileUtils.copyDirectory(target, rollbackDir);
                    } catch (IOException e) {
                        rollbackDir = null;
                    }
                    FileUtil.delete(target);
                }

                boolean restored = false;

                // source 1: original map kept in the plugin Arenas/<arena> folder
                // 自动整理：支持地图在 Arenas/<map>/ 下直接放，也支持多嵌套一层（Arenas/<map>/<world>/）
                File arenasSource = new File(BedWars.plugin.getDataFolder(), "/Arenas/" + a.getArenaName());
                File effectiveSource = null;
                if (arenasSource.isDirectory()) {
                    if (new File(arenasSource, "region").isDirectory() && new File(arenasSource, "level.dat").isFile()) {
                        effectiveSource = arenasSource;
                    } else {
                        File[] nested = arenasSource.listFiles(File::isDirectory);
                        if (nested != null) {
                            for (File sub : nested) {
                                if (new File(sub, "region").isDirectory() && new File(sub, "level.dat").isFile()) {
                                    effectiveSource = sub;
                                    plugin.getLogger().info("地图 " + a.getArenaName() + "：检测到嵌套地图文件夹 " + sub.getName() + "，已自动使用（无需手动调整文件结构）。");
                                    break;
                                }
                            }
                        }
                    }
                }
                if (effectiveSource != null) {
                    try {
                        FileUtils.copyDirectory(effectiveSource, target);
                        restored = true;
                        plugin.getLogger().info("地图世界 " + a.getArenaName() + " 已从地图文件夹恢复。");
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                } else {
                    // tell the admin exactly why the map could not be restored from the Arenas folder
                    if (!arenasSource.isDirectory()) {
                        plugin.getLogger().severe("地图 " + a.getArenaName() + "：在 plugins/BedWars1058/Arenas/" + a.getArenaName() + "/ 未找到地图（文件夹不存在）。请将完整地图放入其中（包含 'region/' 和 'level.dat' 的文件夹，嵌套一层子文件夹也可以）。");
                    } else if (!new File(arenasSource, "region").isDirectory()) {
                        plugin.getLogger().severe("地图 " + a.getArenaName() + "：plugins/BedWars1058/Arenas/" + a.getArenaName() + "/ 缺少 'region' 文件夹。请确保地图文件没有多嵌套一层文件夹。");
                    } else if (!new File(arenasSource, "level.dat").isFile()) {
                        plugin.getLogger().severe("地图 " + a.getArenaName() + "：plugins/BedWars1058/Arenas/" + a.getArenaName() + "/ 缺少 'level.dat'。请复制整个地图文件夹（level.dat 位于其根目录）。");
                    }
                }

                // source 2: backup zip in the Cache folder
                if (!restored) {
                    if (!bf.exists()) {
                        new WorldZipper(a.getArenaName(), true);
                    }
                    if (bf.exists()) {
                        try {
                            ZipFileUtil.unzipFileIntoDirectory(bf, target);
                            restored = true;
                            plugin.getLogger().info("地图世界 " + a.getArenaName() + " 已从备份压缩包恢复。");
                        } catch (IOException e) {
                            plugin.getLogger().warning("Backup zip plugins/BedWars1058/Cache/" + a.getArenaName() + ".zip is corrupted or unreadable and could not be used. Remove it and make sure a complete map exists at plugins/BedWars1058/Arenas/" + a.getArenaName() + "/.");
                        }
                    } else {
                        plugin.getLogger().warning("No backup zip for arena '" + a.getArenaName() + "' and no usable map in the Arenas folder.");
                    }
                }

                // final check: the world folder must contain usable region data
                if (!new File(target, "region").isDirectory() || !new File(target, "level.dat").isFile()) {
                    // 恢复失败：回滚到升级前的世界，保证存档与地图不丢
                    if (rollbackDir != null && rollbackDir.isDirectory()) {
                        FileUtil.delete(target);
                        try {
                            FileUtils.copyDirectory(rollbackDir, target);
                            plugin.getLogger().warning("地图 " + a.getArenaName() + " 世界恢复失败，已回滚到升级前的世界，未丢失存档。请检查地图文件后重试。");
                        } catch (IOException ex) {
                            plugin.getLogger().severe("地图 " + a.getArenaName() + " 世界回滚失败：" + ex.getMessage());
                        }
                    }
                    if (rollbackDir != null) {
                        FileUtil.delete(rollbackDir);
                    }
                    plugin.getLogger().severe("Arena world '" + a.getWorldName() + "' has no readable region/level.dat after restore! The map will load as an empty void world. Make sure the map folder (with region/ and level.dat) exists at plugins/BedWars1058/Arenas/" + a.getArenaName() + "/");
                } else if (rollbackDir != null) {
                    // 恢复成功：清理临时回滚目录
                    FileUtil.delete(rollbackDir);
                }

                deleteWorldTrash(a.getWorldName());

                Bukkit.getScheduler().runTask(plugin, () -> {
                    WorldCreator wc = new WorldCreator(a.getWorldName());
                    wc.generateStructures(false);
                    wc.generator(new VoidChunkGenerator());
                    World w = Bukkit.createWorld(wc);
                    if (w == null){
                        throw new IllegalStateException("World should be null");
                    }
                    w.setKeepSpawnInMemory(true);
                    w.setAutoSave(false);
                    // verify the spawn area actually contains map blocks
                    Bukkit.getScheduler().runTaskLater(getOwner(), () -> {
                        int blocks = 0;
                        int sx = w.getSpawnLocation().getBlockX(), sz = w.getSpawnLocation().getBlockZ();
                        for (int x = -3; x <= 3; x++) {
                            for (int z = -3; z <= 3; z++) {
                                for (int y = 0; y < w.getMaxHeight(); y++) {
                                    if (w.getBlockAt(sx + x, y, sz + z).getType() != Material.AIR) blocks++;
                                }
                            }
                        }
                        if (blocks == 0) {
                            plugin.getLogger().severe("地图世界 " + a.getWorldName() + " 加载为空！地图可能缺失或其区域文件不可读。请检查世界容器中的地图。");
                        } else {
                            plugin.getLogger().info("地图世界 " + a.getWorldName() + " 已加载，出生点附近有 " + blocks + " 个方块。");
                        }
                    }, 60L);
                });
            });
        });
    }

    @Override
    public void onRestart(IArena a) {
        Bukkit.getScheduler().runTask(getOwner(), () -> {
            if (BedWars.getServerType() == ServerType.BUNGEE) {
                if (Arena.getGamesBeforeRestart() == 0) {
                    if (Arena.getArenas().isEmpty()) {
                        plugin.getLogger().info("Dispatching command: " + config.getString(ConfigPath.GENERAL_CONFIGURATION_BUNGEE_OPTION_RESTART_CMD));
                        Bukkit.dispatchCommand(Bukkit.getConsoleSender(), config.getString(ConfigPath.GENERAL_CONFIGURATION_BUNGEE_OPTION_RESTART_CMD));
                    }
                } else {
                    if (Arena.getGamesBeforeRestart() != -1) {
                        Arena.setGamesBeforeRestart(Arena.getGamesBeforeRestart() - 1);
                    }
                    Bukkit.unloadWorld(a.getWorldName(), false);
                    if (Arena.canAutoScale(a.getArenaName())) {
                        Bukkit.getScheduler().runTaskLater(plugin, () -> new Arena(a.getArenaName(), null), 80L);
                    }
                }
            } else {
                Bukkit.unloadWorld(a.getWorldName(), false);
                Bukkit.getScheduler().runTaskLater(plugin, () -> new Arena(a.getArenaName(), null), 80L);
            }
            if (!a.getWorldName().equals(a.getArenaName())) {
                deleteWorld(a.getWorldName());
            }
        });
    }

    @Override
    public void onDisable(IArena a) {
        if(BedWars.isShuttingDown()) {
            Bukkit.unloadWorld(a.getWorldName(), false);
            return;
        }
        Bukkit.getScheduler().runTask(getOwner(), () -> Bukkit.unloadWorld(a.getWorldName(), false));
    }

    @Override
    public void onSetupSessionStart(ISetupSession s) {
        Bukkit.getScheduler().runTaskAsynchronously(getOwner(), () -> {
            File bf = new File(backupFolder, s.getWorldName() + ".zip"), af = new File(Bukkit.getWorldContainer(), s.getWorldName());
            if (bf.exists()) {
                FileUtil.delete(af);
                try {
                    ZipFileUtil.unzipFileIntoDirectory(bf, new File(Bukkit.getWorldContainer(), s.getWorldName()));
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            WorldCreator wc = new WorldCreator(s.getWorldName());
            wc.generator(new VoidChunkGenerator());
            wc.generateStructures(false);
            Bukkit.getScheduler().runTask(getOwner(), () -> {
                try {
                    File level = new File(Bukkit.getWorldContainer(), s.getWorldName() + "/region");
                    if (level.exists()) {
                        s.getPlayer().sendMessage(ChatColor.GREEN + "Loading " + s.getWorldName() + " from Bukkit worlds container.");
                        deleteWorldTrash(s.getWorldName());
                        World w = Bukkit.createWorld(wc);
                        w.setKeepSpawnInMemory(true);
                    } else {
                        try {
                            s.getPlayer().sendMessage(ChatColor.GREEN + "Creating a new void map: " + s.getWorldName());
                            World w = Bukkit.createWorld(wc);
                            w.setKeepSpawnInMemory(true);
                            Bukkit.getScheduler().runTaskLater(plugin, s::teleportPlayer, 20L);
                        } catch (Exception ex){
                            ex.printStackTrace();
                            s.close();
                        }
                        return;
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                    s.close();
                    return;
                }
                Bukkit.getScheduler().runTaskLater(plugin, s::teleportPlayer, 20L);
            });
        });
    }

    @Override
    public void onSetupSessionClose(ISetupSession s) {
        Bukkit.getScheduler().runTask(getOwner(), () -> {
            Bukkit.getWorld(s.getWorldName()).save();
            Bukkit.unloadWorld(s.getWorldName(), true);
            Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> new WorldZipper(s.getWorldName(), true));
        });
    }

    @Override
    public boolean isWorld(String name) {
        return new File(Bukkit.getWorldContainer(), name + "/region").exists();
    }

    @Override
    public void deleteWorld(String name) {
        Bukkit.getScheduler().runTaskAsynchronously(getOwner(), () -> {
            try {
                FileUtils.deleteDirectory(new File(Bukkit.getWorldContainer(), name));
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
    }

    @Override
    public void cloneArena(String name1, String name2) {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                FileUtils.copyDirectory(new File(Bukkit.getWorldContainer(), name1), new File(Bukkit.getWorldContainer(), name2));
                deleteWorldTrash(name2);
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
    }

    @Override
    public List<String> getWorldsList() {
        List<String> worlds = new ArrayList<>();
        File dir = Bukkit.getWorldContainer();
        if (dir.exists()) {
            File[] fls = dir.listFiles();
            for (File fl : Objects.requireNonNull(fls)) {
                if (fl.isDirectory()) {
                    File dat = new File(fl.getName() + "/region");
                    if (dat.exists() && !fl.getName().startsWith("bw_temp")) {
                        worlds.add(fl.getName());
                    }
                }
            }
        }
        return worlds;
    }

    @Override
    public void convertWorlds() {
        File dir = new File(plugin.getDataFolder(), "/Arenas");
        if (dir.exists()) {
            List<File> files = new ArrayList<>();
            File[] fls = dir.listFiles();
            for (File fl : Objects.requireNonNull(fls)) {
                if (fl.isFile()) {
                    if (fl.getName().contains(".yml")) {
                        files.add(fl);
                    }
                }
            }

            // lowerCase arena names - new 1.14 standard
            File folder, newName;

            List<File> toRemove = new ArrayList<>(), toAdd = new ArrayList<>();
            for (File file : files) {
                if (!file.getName().equals(file.getName().toLowerCase())) {
                    newName = new File(dir.getPath() + "/" + file.getName().toLowerCase());
                    if (!file.renameTo(newName)) {
                        toRemove.add(file);
                        BedWars.plugin.getLogger().severe("Could not rename " + file.getName() + " to " + file.getName().toLowerCase() + "! Please do it manually!");
                    } else {
                        toAdd.add(newName);
                        toRemove.add(file);
                    }
                    folder = new File(plugin.getServer().getWorldContainer(), file.getName().replace(".yml", ""));
                    if (folder.exists()) {
                        if (!folder.getName().equals(folder.getName().toLowerCase())) {
                            if (!folder.renameTo(new File(plugin.getServer().getWorldContainer().getPath() + "/" + folder.getName().toLowerCase()))) {
                                BedWars.plugin.getLogger().severe("Could not rename " + folder.getName() + " folder to " + folder.getName().toLowerCase() + "! Please do it manually!");
                                toRemove.add(file);
                                return;
                            }
                        }
                    }
                }
            }

            for (File f : toRemove) {
                files.remove(f);
            }

            files.addAll(toAdd);
        }
        Bukkit.getScheduler().runTaskAsynchronously(getOwner(), () -> {
            File[] files = Bukkit.getWorldContainer().listFiles();
            if (files != null) {
                for (File f : files) {
                    if (f != null && f.isDirectory()) {
                        if (f.getName().contains("bw_temp_")) {
                            deleteWorld(f.getName());
                        }
                    }
                }
            }
        });
    }

    @Override
    public String getDisplayName() {
        return "Internal Restore Adapter";
    }

    private void deleteWorldTrash(String world) {
        for (File f : new File[]{new File(Bukkit.getWorldContainer(), world + "/level.dat"),
                new File(Bukkit.getWorldContainer(), world + "/level.dat_mcr"),
                new File(Bukkit.getWorldContainer(), world + "/level.dat_old"),
                new File(Bukkit.getWorldContainer(), world + "/session.lock"),
                new File(Bukkit.getWorldContainer(), world + "/uid.dat")}) {
            if (f.exists()) {
                if (!f.delete()) {
                    getOwner().getLogger().warning("Could not delete: " + f.getPath());
                    getOwner().getLogger().warning("This may cause issues!");
                }
            }
        }
    }
}