package com.andrei1058.bedwars.sidebar;

import org.bukkit.ChatColor;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * 外部 Tab / 侧边栏外观配置。
 * 插件根目录下的 tab.yml（Tab 头/尾/前缀后缀）和 ce.yml（侧边栏标题/内容）。
 * 服主直接改这两个文件即可自定义文案和配色，无需改代码。
 */
public class ExternalTextConfig {

    private static File tabFile, ceFile;
    private static YamlConfiguration tabYml, ceYml;
    private static boolean loaded = false;

    public static void init(JavaPlugin plugin) {
        File dataFolder = plugin.getDataFolder();
        if (!dataFolder.exists()) dataFolder.mkdirs();

        tabFile = new File(dataFolder, "tab.yml");
        ceFile = new File(dataFolder, "ce.yml");

        if (!tabFile.exists()) writeDefaultTab(plugin);
        if (!ceFile.exists()) writeDefaultCe(plugin);

        tabYml = YamlConfiguration.loadConfiguration(tabFile);
        ceYml = YamlConfiguration.loadConfiguration(ceFile);
        loaded = true;
    }

    /** 重新加载（/reload 后用） */
    public static void reload() {
        if (tabFile != null) tabYml = YamlConfiguration.loadConfiguration(tabFile);
        if (ceFile != null) ceYml = YamlConfiguration.loadConfiguration(ceFile);
    }

    private static void writeDefaultTab(JavaPlugin plugin) {
        YamlConfiguration yml = new YamlConfiguration();
        yml.options().header(
                "BedWars1058 Tab 外观配置\n" +
                "================================\n" +
                "直接修改本文件即可自定义 Tab（玩家列表）的头部、底部、玩家名前缀/后缀。\n" +
                "颜色用 & 开头（如 &e 黄色），空行写 \"\"。\n" +
                "可用占位符：\n" +
                "  {brand}      服务器品牌（见下方 brand 字段）\n" +
                "  {arena}      竞技场名（如 4v4v4v4#4）\n" +
                "  {map}        地图名\n" +
                "  {mode}       模式\n" +
                "  {time}       倒计时\n" +
                "  {nextEvent}  下一事件（如 钻石II级）\n" +
                "  {player}     玩家名\n" +
                "  {kills} {finalKills} {beds} {deaths}  本局数据（结算页）\n" +
                "  {winnerTeamName}  胜者队伍名\n" +
                "  {level}      玩家等级\n" +
                "  {teamColor} {teamName}  队伍颜色/名称（前缀里用）\n" +
                "  {on} {max}   在线/最大人数\n" +
                "  {qq}         QQ群号（见下方 qq 字段）\n" +
                "  {domain}     服务器域名（见下方 domain 字段）\n" +
                "  {serverIp}   服务器 IP\n" +
                "================================\n");

        yml.set("brand", "&6☀ &e我的服务器 &f把这里改成你的服务器标语");
        yml.set("qq", "123456789");
        yml.set("domain", "www.example.com");

        // header（Tab 顶部，多行列表）
        yml.set("header.lobby", Arrays.asList(
                "{brand}",
                "&6&m─────────────────",
                "",
                "&7在线玩家: &e{on}"));

        yml.set("header.waiting", Arrays.asList(
                "{brand}",
                "&6&m─────────────────",
                "&e►当前服务器: 起床战争{arena}◄",
                "&7地图: &f{map}",
                "",
                "&7等待玩家加入..."));

        yml.set("header.starting", Arrays.asList(
                "{brand}",
                "&6&m─────────────────",
                "&e►当前服务器: 起床战争{arena}◄",
                "&7地图: &f{map}",
                "",
                "&e游戏将在 &f{time} &e秒后开始！"));

        yml.set("header.playing", Arrays.asList(
                "{brand}",
                "&6&m─────────────────",
                "&e►当前服务器: 起床战争{arena}◄",
                "&7地图: &f{map} &7| 模式: &f{mode}",
                "&e{time} 后 {nextEvent}"));

        // 结算页：胜者视角
        yml.set("header.restarting_win", Arrays.asList(
                "{brand}",
                "&6&m─────────────────",
                "&e►当前服务器: 起床战争{arena}◄",
                "",
                "&e★ 你的队伍赢得了比赛！★",
                "",
                "&7{player}",
                "&e击杀: &f{kills}&e | 终结击杀: &f{finalKills}&e | 摧毁床: &f{beds}&e | 死亡: &f{deaths}"));

        // 结算页：败者/淘汰视角
        yml.set("header.restarting_lose", Arrays.asList(
                "{brand}",
                "&6&m─────────────────",
                "&e►当前服务器: 起床战争{arena}◄",
                "",
                "&c★ 你的队伍输掉了比赛 ★",
                "",
                "&7{player}",
                "&e击杀: &f{kills}&e | 终结击杀: &f{finalKills}&e | 摧毁床: &f{beds}&e | 死亡: &f{deaths}"));

        // footer（Tab 底部）
        yml.set("footer.default", Arrays.asList(
                "&e►服务器QQ群: &f{qq}&e◄",
                "&6&m─────────────────",
                "&e{domain}"));

        // 玩家名前缀/后缀
        yml.set("prefix.lobby", "&7");
        yml.set("prefix.waiting", "&7");
        yml.set("prefix.starting", "&7");
        yml.set("prefix.playing", "{teamColor}[{teamName}&7] ");
        yml.set("prefix.spectator", "&7");
        yml.set("prefix.eliminated", "&7");
        yml.set("prefix.restarting", "{teamColor}[{teamName}&7] ");

        yml.set("suffix.lobby", "&7");
        yml.set("suffix.waiting", "&7");
        yml.set("suffix.starting", "&7");
        yml.set("suffix.playing", "&7 [Lv.{levelUnformatted}]");
        yml.set("suffix.spectator", "&7");
        yml.set("suffix.eliminated", "&7");
        yml.set("suffix.restarting", "&7 [Lv.{levelUnformatted}]");

        try {
            yml.save(tabFile);
        } catch (IOException e) {
            plugin.getLogger().warning("无法写入 tab.yml: " + e.getMessage());
        }
    }

    private static void writeDefaultCe(JavaPlugin plugin) {
        YamlConfiguration yml = new YamlConfiguration();
        yml.options().header(
                "BedWars1058 侧边栏配置（ce = 侧边栏）\n" +
                "================================\n" +
                "直接修改本文件即可自定义右侧计分板。\n" +
                "颜色用 & 开头，空行写 \"\"。\n" +
                "第一行是标题（用英文逗号 , 分隔可做多帧动画）。\n" +
                "可用占位符：\n" +
                "  {team}       自动展开为每队一行（按队伍数量自动重复）\n" +
                "  {time}       倒计时\n" +
                "  {nextEvent}  下一事件\n" +
                "  {winnerTeamName} {winnerTeamColor}  胜者队伍\n" +
                "  {topTeamColor}{topPlayerDisplayName} - {topValue}  总击杀榜（一行一个玩家，可重复多行）\n" +
                "  {player} {kills} {finalKills} {beds} {deaths}  本局数据\n" +
                "  {on} {max}   在线/最大人数\n" +
                "  {level}      玩家等级\n" +
                "  {serverIp}   服务器 IP\n" +
                "================================\n");

        yml.set("title", "&e&l起床战争");

        // 大厅侧边栏
        yml.set("lobby", Arrays.asList(
                "&e&l起床战争",
                "&f{player}",
                "",
                "&7等级: &a{levelUnformatted}☆",
                "&7击杀: &a{kills}",
                "&7在线: &a{on}",
                "",
                "&7{domain}"));

        // 等待加入
        yml.set("waiting", Arrays.asList(
                "&e&l起床战争",
                "",
                "&7等待玩家加入...",
                "&7在线: &e{on}&7/&e{max}",
                "",
                "&7地图: &f{map}",
                "",
                "&7{domain}"));

        // 开始倒计时
        yml.set("starting", Arrays.asList(
                "&e&l起床战争",
                "",
                "&7游戏即将开始",
                "&7倒计时: &e{time}",
                "",
                "{team}",
                "{team}",
                "{team}",
                "{team}",
                "",
                "&7{domain}"));

        // 游戏中（活着）
        yml.set("playing", Arrays.asList(
                "&e&l起床战争",
                "&7{nextEvent} - &e{time}",
                "",
                "{team}",
                "{team}",
                "{team}",
                "{team}",
                "",
                "&7{domain}"));

        // 游戏中（观战/淘汰）
        yml.set("playing_spectator", Arrays.asList(
                "&e&l起床战争",
                "&7{nextEvent} - &e{time}",
                "",
                "&o&7观战中",
                "",
                "{team}",
                "{team}",
                "{team}",
                "{team}",
                "",
                "&7{domain}"));

        // 结算（胜者）
        yml.set("restarting_win", Arrays.asList(
                "&e&l起床战争",
                "&7| 胜者: &f{winnerTeamName} &6★",
                "",
                "&7| 总击杀榜:",
                "&7{topTeamColor}{topPlayerDisplayName}&7 - &e{topValue}",
                "&7{topTeamColor}{topPlayerDisplayName}&7 - &e{topValue}",
                "&7{topTeamColor}{topPlayerDisplayName}&7 - &e{topValue}",
                "&7{topTeamColor}{topPlayerDisplayName}&7 - &e{topValue}",
                "&7{topTeamColor}{topPlayerDisplayName}&7 - &e{topValue}",
                "",
                "&7{domain}"));

        // 结算（败者）
        yml.set("restarting_lose", Arrays.asList(
                "&e&l起床战争",
                "&7| 胜者: &f{winnerTeamName} &6★",
                "",
                "&7| 总击杀榜:",
                "&7{topTeamColor}{topPlayerDisplayName}&7 - &e{topValue}",
                "&7{topTeamColor}{topPlayerDisplayName}&7 - &e{topValue}",
                "&7{topTeamColor}{topPlayerDisplayName}&7 - &e{topValue}",
                "&7{topTeamColor}{topPlayerDisplayName}&7 - &e{topValue}",
                "&7{topTeamColor}{topPlayerDisplayName}&7 - &e{topValue}",
                "",
                "&7{domain}"));

        try {
            yml.save(ceFile);
        } catch (IOException e) {
            plugin.getLogger().warning("无法写入 ce.yml: " + e.getMessage());
        }
    }

    // ============ 读取接口 ============

    /** Tab header（多行），状态不存在返回 null（回退到语言文件） */
    public static List<String> getHeader(String state) {
        if (!loaded) return null;
        List<String> list = tabYml.getStringList("header." + state);
        return list.isEmpty() ? null : translate(list);
    }

    /** Tab footer（多行） */
    public static List<String> getFooter() {
        if (!loaded) return null;
        List<String> list = tabYml.getStringList("footer.default");
        return list.isEmpty() ? null : translate(list);
    }

    /** 玩家前缀 */
    public static String getPrefix(String state) {
        if (!loaded) return null;
        String s = tabYml.getString("prefix." + state);
        return s == null ? null : translate(s);
    }

    /** 玩家后缀 */
    public static String getSuffix(String state) {
        if (!loaded) return null;
        String s = tabYml.getString("suffix." + state);
        return s == null ? null : translate(s);
    }

    /** 侧边栏标题 */
    public static String getSidebarTitle() {
        if (!loaded) return null;
        String s = ceYml.getString("title");
        return s == null ? null : translate(s);
    }

    /** 侧边栏内容行（不含标题） */
    public static List<String> getSidebarLines(String state) {
        if (!loaded) return null;
        List<String> list = ceYml.getStringList(state);
        return list.isEmpty() ? null : translate(list);
    }

    /** QQ群号 */
    public static String getQq() {
        if (!loaded) return "";
        return tabYml.getString("qq", "");
    }

    /** 服务器域名 */
    public static String getDomain() {
        if (!loaded) return "";
        return tabYml.getString("domain", "");
    }

    /** 服务器品牌（已转色） */
    public static String getBrand() {
        if (!loaded) return "";
        return translate(tabYml.getString("brand", ""));
    }

    private static String translate(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }

    private static List<String> translate(List<String> list) {
        List<String> out = new ArrayList<>();
        for (String s : list) out.add(translate(s));
        return out;
    }
}
