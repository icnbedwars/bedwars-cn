/*
 * BedWars1058 - A bed wars mini-game.
 * Copyright (C) 2021 Andrei Dascălu
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *
 * Contact e-mail: andrew.dascalu@gmail.com
 */

package com.andrei1058.bedwars;

import com.andrei1058.bedwars.api.arena.IArena;
import com.andrei1058.bedwars.api.configuration.ConfigManager;
import com.andrei1058.bedwars.api.configuration.ConfigPath;
import com.andrei1058.bedwars.api.language.Language;
import com.andrei1058.bedwars.api.levels.Level;
import com.andrei1058.bedwars.api.party.Party;
import com.andrei1058.bedwars.api.server.RestoreAdapter;
import com.andrei1058.bedwars.api.server.ServerType;
import com.andrei1058.bedwars.api.server.VersionSupport;
import com.andrei1058.bedwars.arena.Arena;
import com.andrei1058.bedwars.arena.ArenaManager;
import com.andrei1058.bedwars.arena.VoidChunkGenerator;
import com.andrei1058.bedwars.arena.despawnables.TargetListener;
import com.andrei1058.bedwars.arena.feature.SpoilPlayerTNTFeature;
import com.andrei1058.bedwars.arena.spectator.SpectatorListeners;
import com.andrei1058.bedwars.arena.stats.DefaultStatsHandler;
import com.andrei1058.bedwars.arena.tasks.OneTick;
import com.andrei1058.bedwars.arena.tasks.Refresh;
import com.andrei1058.bedwars.arena.upgrades.BaseListener;
import com.andrei1058.bedwars.arena.upgrades.HealPoolListner;
import com.andrei1058.bedwars.commands.bedwars.MainCommand;
import com.andrei1058.bedwars.commands.leave.LeaveCommand;
import com.andrei1058.bedwars.commands.party.PartyCommand;
import com.andrei1058.bedwars.commands.rejoin.RejoinCommand;
import com.andrei1058.bedwars.commands.shout.ShoutCommand;
import com.andrei1058.bedwars.configuration.*;
import com.andrei1058.bedwars.database.Database;
import com.andrei1058.bedwars.database.SQLite;
import com.andrei1058.bedwars.halloween.HalloweenSpecial;
import com.andrei1058.bedwars.language.*;
import com.andrei1058.bedwars.levels.internal.InternalLevel;
import com.andrei1058.bedwars.levels.internal.LevelListeners;
import com.andrei1058.bedwars.listeners.*;
import com.andrei1058.bedwars.listeners.arenaselector.ArenaSelectorListener;
import com.andrei1058.bedwars.listeners.blockstatus.BlockStatusListener;
import com.andrei1058.bedwars.listeners.chat.ChatAFK;
import org.bukkit.enchantments.Enchantment;

import java.util.HashMap;
import java.util.Map;
import com.andrei1058.bedwars.listeners.chat.ChatFormatting;
import com.andrei1058.bedwars.listeners.joinhandler.*;
import com.andrei1058.bedwars.lobbysocket.ArenaSocket;
import com.andrei1058.bedwars.lobbysocket.LoadedUsersCleaner;
import com.andrei1058.bedwars.lobbysocket.SendTask;
import com.andrei1058.bedwars.maprestore.internal.InternalAdapter;
import com.andrei1058.bedwars.metrics.MetricsManager;
import com.andrei1058.bedwars.money.internal.MoneyListeners;
import com.andrei1058.bedwars.shop.ShopManager;
import com.andrei1058.bedwars.sidebar.*;
import com.andrei1058.bedwars.stats.StatsManager;
import com.andrei1058.bedwars.support.citizens.CitizensListener;
import com.andrei1058.bedwars.support.citizens.JoinNPC;
import com.andrei1058.bedwars.support.papi.PAPISupport;
import com.andrei1058.bedwars.support.papi.SupportPAPI;
import com.andrei1058.bedwars.support.party.NoParty;
import com.andrei1058.bedwars.support.party.PAF;
import com.andrei1058.bedwars.support.party.PAFBungeecordRedisApi;
import com.andrei1058.bedwars.support.party.PartiesAdapter;
import com.andrei1058.bedwars.support.preloadedparty.PrePartyListener;
import com.andrei1058.bedwars.support.vault.*;
import com.andrei1058.bedwars.support.vipfeatures.VipFeatures;
import com.andrei1058.bedwars.support.vipfeatures.VipListeners;
import com.andrei1058.vipfeatures.api.IVipFeatures;
import com.andrei1058.vipfeatures.api.MiniGameAlreadyRegistered;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Monster;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.generator.ChunkGenerator;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.PluginDescriptionFile;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.ServicePriority;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.*;

@SuppressWarnings({"WeakerAccess", "CallToPrintStackTrace"})
public class BedWars extends JavaPlugin {

    private static ServerType serverType = ServerType.MULTIARENA;
    public static boolean debug = true, autoscale = false;
    public static String mainCmd = "bw", link = "https://www.spigotmc.org/resources/50942/";
    public static ConfigManager signs, generators;
    public static MainConfig config;
    public static ShopManager shop;
    public static StatsManager statsManager;
    public static BedWars plugin;
    public static VersionSupport nms;

    public static boolean isPaper = false;

    private static Party party = new NoParty();
    private static Chat chat = new NoChat();
    protected static Level level;
    private static Economy economy;
    private static final String version = detectServerVersionIdentifier();
    private static String lobbyWorld = "";
    private static boolean shuttingDown = false;

    public static ArenaManager arenaManager = new ArenaManager();

    //remote database
    private static Database remoteDatabase;

    private boolean serverSoftwareSupport = true;

    private static com.andrei1058.bedwars.api.BedWars api;

    @Override
    public void onLoad() {

        //Spigot support
        try {
            Class.forName("org.spigotmc.SpigotConfig");
        } catch (Exception ignored) {
            this.getLogger().severe("无法在当前服务器软件上运行。请查看:");
            this.getLogger().severe("https://gitlab.com/andrei1058/BedWars1058/wikis/compatibility");
            serverSoftwareSupport = false;
            return;
        }

        try {
            Class.forName("com.destroystokyo.paper.PaperConfig");
            isPaper = true;
        } catch (ClassNotFoundException e) {
            isPaper = false;
        }

        plugin = this;

        /* BadWars-CN 独立分支：插件数据目录已改为 BadWars-CN。
         * 首次启用时自动把旧 BedWars1058 数据目录（config/语言/Arenas/等）完整复制过来，
         * 保证升级改名不丢任何配置。 */
        migrateLegacyData();

        /* Load version support */
        //noinspection rawtypes
        Class supp;

        try {
            supp = Class.forName("com.andrei1058.bedwars.support.version." + version + "." + version);
        } catch (ClassNotFoundException e) {
            serverSoftwareSupport = false;
            this.getLogger().severe("无法在当前版本上运行: " + version);
            return;
        }
        api = new API();
        Bukkit.getServicesManager().register(com.andrei1058.bedwars.api.BedWars.class, api, this, ServicePriority.Highest);

        try {
            //noinspection unchecked
            nms = (VersionSupport) supp.getConstructor(Class.forName("org.bukkit.plugin.Plugin"), String.class).newInstance(this, version);
        } catch (InstantiationException | NoSuchMethodException | InvocationTargetException | IllegalAccessException |
                 ClassNotFoundException e) {
            e.printStackTrace();
            serverSoftwareSupport = false;
            this.getLogger().severe("无法加载对服务器版本的支持: " + version);
            return;
        }

        this.getLogger().info("正在加载对 paper/spigot 的支持: " + version);

        // Setup languages
        new English();
        new Romanian();
        new Italian();
        new Polish();
        new Spanish();
        new Russian();
        new Bangla();
        new Persian();
        new Hindi();
        new Indonesia();
        new Portuguese();
        new SimplifiedChinese();
        new Turkish();

        config = new MainConfig(this, "config");

        generators = new GeneratorsConfig(this, "generators", this.getDataFolder().getPath());
        // Initialize signs config after the main config
        if (getServerType() != ServerType.BUNGEE) {
            signs = new SignsConfig(this, "signs", this.getDataFolder().getPath());
        }
    }

    /**
     * BadWars-CN 独立分支数据迁移：
     * 插件改名后数据目录从 plugins/BedWars1058 变为 plugins/BadWars-CN。
     * 若新目录不存在（或为空）且旧目录存在，则将旧目录完整复制到新目录，
     * 这样服务器升级改名后所有配置、语言、Arenas 地图、商店文件都不丢失。
     */
    private void migrateLegacyData() {
        File newDir = getDataFolder();
        File legacyDir = new File(newDir.getParentFile(), "BedWars1058");
        if (!legacyDir.isDirectory()) return;
        if (newDir.exists() && newDir.list().length > 0) return;
        try {
            if (!newDir.exists() && !newDir.mkdirs()) {
                getLogger().warning("无法创建数据目录: " + newDir.getPath());
                return;
            }
            copyRecursively(legacyDir, newDir);
            getLogger().info("已将旧 BedWars1058 数据目录迁移到 " + newDir.getName() + " ✓");
        } catch (IOException ex) {
            getLogger().severe("迁移旧 BedWars1058 数据目录失败: " + ex.getMessage());
        }
    }

    private void copyRecursively(File src, File dst) throws IOException {
        if (src.isDirectory()) {
            File[] children = src.listFiles();
            if (children == null) return;
            for (File child : children) {
                copyRecursively(child, new File(dst, child.getName()));
            }
        } else {
            File parent = dst.getParentFile();
            if (parent != null && !parent.exists() && !parent.mkdirs()) {
                throw new IOException("无法创建目录: " + parent.getPath());
            }
            Files.copy(src.toPath(), dst.toPath(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.COPY_ATTRIBUTES);
        }
    }

    @Override
    public void onEnable() {
        if (!serverSoftwareSupport) {
            Bukkit.getPluginManager().disablePlugin(this);
            return;
        }

        nms.registerVersionListeners();

        if (!this.handleWorldAdapter()) {
            api.setRestoreAdapter(new InternalAdapter(this));
            getLogger().info("使用内置世界恢复系统。");
        }

        /* Register commands */
        MainCommand mainCommand = new MainCommand(mainCmd);
        // BadWars-CN 独立分支：新增主指令别名 /badwarscn（与原 /bw 完全等价）
        List<String> aliases = new ArrayList<>(mainCommand.getAliases());
        aliases.add("badwarscn");
        mainCommand.setAliases(aliases);
        nms.registerCommand(mainCmd, mainCommand);
        // 全服喊话：/hh <内容>（任意玩家可用，无需 OP）
        nms.registerCommand("hh", new com.andrei1058.bedwars.commands.bedwars.HhCommand());

        // newer versions do not seem to like delayed registration of commands
        if (nms.getVersion() >= 9) {
            this.registerDelayedCommands();
        } else {
            Bukkit.getScheduler().runTaskLater(this, this::registerDelayedCommands, 20L);
        }

        /* Setup plugin messaging channel */
        Bukkit.getServer().getMessenger().registerOutgoingPluginChannel(this, "BungeeCord");

        // define logger
        var out = plugin.getLogger();

        /* Check if lobby location is set. Required for non Bungee servers */
        if (config.getLobbyWorldName().isEmpty() && serverType != ServerType.BUNGEE) {
            out.log(java.util.logging.Level.WARNING, "Lobby location is not set!");
        }

        /* Load lobby world if not main level
         * when the server finishes loading. */
        if (getServerType() == ServerType.MULTIARENA)
            Bukkit.getScheduler().runTaskLater(this, () -> {
                if (!config.getLobbyWorldName().isEmpty()) {
                    if (Bukkit.getWorld(config.getLobbyWorldName()) == null && new File(Bukkit.getWorldContainer(), config.getLobbyWorldName() + "/level.dat").exists()) {
                        if (!config.getLobbyWorldName().equalsIgnoreCase(Bukkit.getServer().getWorlds().get(0).getName())) {
                            Bukkit.getScheduler().runTaskLater(this, () -> {
                                Bukkit.createWorld(new WorldCreator(config.getLobbyWorldName()));

                                if (Bukkit.getWorld(config.getLobbyWorldName()) != null) {
                                    Bukkit.getScheduler().runTaskLater(plugin, () -> Objects.requireNonNull(Bukkit.getWorld(config.getLobbyWorldName()))
                                            .getEntities().stream().filter(e -> e instanceof Monster).forEach(Entity::remove), 20L);
                                }
                            }, 100L);
                        }
                    }
                    Location l = config.getConfigLoc("lobbyLoc");
                    if (l != null) {
                        World w = Bukkit.getWorld(config.getLobbyWorldName());
                        if (w != null) {
                            w.setSpawnLocation(l.getBlockX(), l.getBlockY(), l.getBlockZ());
                        }
                    }
                }
            }, 1L);

        // Register events
        registerEvents(
                new EnderPearlLanded(), new QuitAndTeleportListener(), new BreakPlace(), new DamageDeathMove(),
                new Inventory(), new Interact(), new RefreshGUI(), new HungerWeatherSpawn(), new CmdProcess(),
                new FireballListener(), new EggBridge(), new SpectatorListeners(), new BaseListener(),
                new TargetListener(), new LangListener(), new Warnings(this), new ChatAFK(),
                new GameEndListener(), new DefaultStatsHandler(), new TeamSelectorListener(), new ExpBarMoney(),
                new HomeScrollAndTrackerListener()
        );
        // 原生经验模式：把背包资源折算成经验值显示在经验条上
        ExpBarMoney.init();

        if (config.getBoolean(ConfigPath.GENERAL_CONFIGURATION_HEAL_POOL_ENABLE)) {
            registerEvents(new HealPoolListner());
        }

        if (getServerType() == ServerType.BUNGEE) {
            if (autoscale) {
                //registerEvents(new ArenaListeners());
                ArenaSocket.lobbies.addAll(config.getList(ConfigPath.GENERAL_CONFIGURATION_BUNGEE_OPTION_LOBBY_SERVERS));
                new SendTask();
                registerEvents(new AutoscaleListener(), new PrePartyListener(), new JoinListenerBungee());
                Bukkit.getScheduler().runTaskTimerAsynchronously(this, new LoadedUsersCleaner(), 60L, 60L);
            } else {
                registerEvents(new ServerPingListener(), new JoinListenerBungeeLegacy());
            }
        } else if (getServerType() == ServerType.MULTIARENA || getServerType() == ServerType.SHARED) {
            registerEvents(new ArenaSelectorListener(), new BlockStatusListener());
            if (getServerType() == ServerType.MULTIARENA) {
                registerEvents(new JoinListenerMultiArena());
            } else {
                registerEvents(new JoinListenerShared());
            }
        }

        registerEvents(new WorldLoadListener());

        if (!(getServerType() == ServerType.BUNGEE && autoscale)) {
            registerEvents(new JoinHandlerCommon());
        }

        // Register setup-holograms fix
        registerEvents(new ChunkLoad());

        registerEvents(new InvisibilityPotionListener());

        /* Load join signs. */
        loadArenasAndSigns();

        /* BedWars1058 needs flight: waiting rooms and spectators are set to fly.
           If allow-flight is disabled the server kicks those players ("Flying is not enabled"),
           which looks like a plugin bug. Enable it at runtime and persist it. */
        if (!Bukkit.getAllowFlight()) {
            boolean ok = false;
            Object server = Bukkit.getServer();
            /* Paper/Spigot: CraftServer -> field "console" (MinecraftServer) -> setFlightAllowed(boolean) */
            Object mcServer = null;
            try {
                java.lang.reflect.Field consoleField = server.getClass().getDeclaredField("console");
                consoleField.setAccessible(true);
                mcServer = consoleField.get(server);
            } catch (Throwable ignored) {
                // fall through
            }
            if (mcServer != null) {
                /* try public setter first, then any method containing "lightAllowed", then the field */
                try {
                    java.lang.reflect.Method m = mcServer.getClass().getMethod("setFlightAllowed", boolean.class);
                    m.invoke(mcServer, true);
                    ok = true;
                } catch (Throwable ignored) {
                    try {
                        for (java.lang.reflect.Method m : mcServer.getClass().getMethods()) {
                            if (m.getName().toLowerCase().contains("lightallowed") && m.getParameterCount() == 1 && m.getParameterTypes()[0] == boolean.class) {
                                m.invoke(mcServer, true);
                                ok = true;
                                break;
                            }
                        }
                    } catch (Throwable ignored2) {
                        // fall through
                    }
                    if (!ok) {
                        try {
                            java.lang.reflect.Field ff = mcServer.getClass().getDeclaredField("flightAllowed");
                            ff.setAccessible(true);
                            ff.setBoolean(mcServer, true);
                            ok = true;
                        } catch (Throwable ignored3) {
                            // fall through
                        }
                    }
                }
            }
            if (!ok) {
                /* fallback: try a direct field on the server object or its superclass */
                try {
                    java.lang.reflect.Field f = server.getClass().getDeclaredField("allowFlight");
                    f.setAccessible(true);
                    f.setBoolean(server, true);
                    ok = true;
                } catch (Throwable ignored) {
                    try {
                        java.lang.reflect.Field f2 = server.getClass().getSuperclass().getDeclaredField("allowFlight");
                        f2.setAccessible(true);
                        f2.setBoolean(server, true);
                        ok = true;
                    } catch (Throwable ignored2) {
                        // warn below
                    }
                }
            }
            if (ok) {
                out.warning("allow-flight was disabled. BedWars1058 enabled it automatically (required for waiting rooms & spectators).");
            } else {
                out.warning("allow-flight is disabled and could not be enabled automatically! Set allow-flight=true in server.properties or players in waiting rooms / spectators will be kicked for flying.");
            }
            /* persist into server.properties so a restart keeps it */
            try {
                java.io.File sp = new java.io.File(Bukkit.getWorldContainer(), "server.properties");
                if (sp.isFile()) {
                    java.util.List<String> lines = new java.util.ArrayList<>();
                    boolean replaced = false;
                    for (String line : java.nio.file.Files.readAllLines(sp.toPath())) {
                        if (line.startsWith("allow-flight=")) {
                            lines.add("allow-flight=true");
                            replaced = true;
                        } else {
                            lines.add(line);
                        }
                    }
                    if (!replaced) lines.add("allow-flight=true");
                    java.nio.file.Files.write(sp.toPath(), lines);
                }
            } catch (Throwable ignored) {
            }
        }

        statsManager = new StatsManager();

        /* Party support */
        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (config.getYml().getBoolean(ConfigPath.GENERAL_CONFIGURATION_ALLOW_PARTIES)) {

                if (getServer().getPluginManager().isPluginEnabled("Parties")) {
                    out.info("Hook into Parties (by AlessioDP) support!");
                    party = new PartiesAdapter();
                } else if (Bukkit.getServer().getPluginManager().isPluginEnabled("PartyAndFriends")) {
                    out.info("Hook into Party and Friends for Spigot (by Simonsator) support!");
                    party = new PAF();
                } else if (Bukkit.getServer().getPluginManager().isPluginEnabled("Spigot-Party-API-PAF")) {
                    out.info("Hook into Spigot Party API for Party and Friends Extended (by Simonsator) support!");
                    party = new PAFBungeecordRedisApi();
                }

                if (party instanceof NoParty) {
                    party = new com.andrei1058.bedwars.support.party.Internal();
                    out.info("Loading internal Party system. /party");
                }
            } else {
                party = new NoParty();
            }
        }, 10L);

        /* Levels support */
        setLevelAdapter(new InternalLevel());

        /* Register tasks */
        Bukkit.getScheduler().runTaskTimer(this, new Refresh(), 20L, 20L);
        //new Refresh().runTaskTimer(this, 20L, 20L);

        if (config.getBoolean(ConfigPath.GENERAL_CONFIGURATION_PERFORMANCE_ROTATE_GEN)) {
            //new OneTick().runTaskTimer(this, 120, 1);
            Bukkit.getScheduler().runTaskTimer(this, new OneTick(), 120, 1);
        }

        /* Register NMS entities */
        nms.registerEntities();

        /* Database support */
        if (config.getBoolean("database.enable")) {
            com.andrei1058.bedwars.database.MySQL mySQL = new com.andrei1058.bedwars.database.MySQL();
            long time = System.currentTimeMillis();
            if (!mySQL.connect()) {
                this.getLogger().severe("无法连接数据库！请检查账号密码，并确认服务器 IP 已在 MySQL 中列入白名单。");
                remoteDatabase = new SQLite();
            } else {
                remoteDatabase = mySQL;
            }
            if (System.currentTimeMillis() - time >= 5000) {
                this.getLogger().severe("建立数据库连接耗时 " + ((System.currentTimeMillis() - time) / 1000) + " 秒！\n" +
                        "不建议使用远程连接！");
            }
            remoteDatabase.init();
        } else {
            remoteDatabase = new SQLite();
            remoteDatabase.init();
        }

        /* Citizens support */
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (this.getServer().getPluginManager().getPlugin("Citizens") != null) {
                JoinNPC.setCitizensSupport(true);
                out.info("Hook into Citizens support. /bw npc");
                registerEvents(new CitizensListener());
            }

            //spawn NPCs
            try {
                JoinNPC.spawnNPCs();
            } catch (Exception e) {
                this.getLogger().severe("无法生成 CmdJoin NPC。请确认服务器安装了正确版本的 Citizens！");
                JoinNPC.setCitizensSupport(false);
            }
        }, 5L);

        /* Save messages for stats gui items if custom items added, for each language */
        Language.setupCustomStatsMessages();

        /* PlaceholderAPI Support */
        if (Bukkit.getPluginManager().getPlugin("PlaceholderAPI") != null) {
            out.info("Hooked into PlaceholderAPI support!");
            new PAPISupport().register();
            SupportPAPI.setSupportPAPI(new SupportPAPI.withPAPI());
        }
        /*
         * Vault support
         * The task is to initialize after all plugins have loaded,
         *  to make sure any economy/chat plugins have been loaded and registered.
         */
        Bukkit.getScheduler().runTask(this, () -> {
            if (this.getServer().getPluginManager().getPlugin("Vault") != null) {
                try {
                    //noinspection rawtypes
                    RegisteredServiceProvider rsp = this.getServer().getServicesManager().getRegistration(net.milkbowl.vault.chat.Chat.class);
                    if (rsp != null) {
                        WithChat.setChat((net.milkbowl.vault.chat.Chat) rsp.getProvider());
                        plugin.getLogger().info("已接入 Vault 聊天支持！");
                        chat = new WithChat();
                    } else {
                        plugin.getLogger().info("已找到 Vault，但没有聊天提供者！");
                        chat = new NoChat();
                    }
                } catch (Exception var2_2) {
                    chat = new NoChat();
                }
                try {
                    registerEvents(new MoneyListeners());
                    RegisteredServiceProvider<net.milkbowl.vault.economy.Economy> rsp = this.getServer().getServicesManager().getRegistration(net.milkbowl.vault.economy.Economy.class);
                    if (rsp != null) {
                        WithEconomy.setEconomy(rsp.getProvider());
                        plugin.getLogger().info("已接入 Vault 经济支持！");
                        economy = new WithEconomy();
                    } else {
                        plugin.getLogger().info("已找到 Vault，但没有经济提供者！");
                        economy = new NoEconomy();
                    }
                } catch (Exception var2_2) {
                    economy = new NoEconomy();
                }
            } else {
                chat = new NoChat();
                economy = new NoEconomy();
            }
        });

        /* Chat support */
        if (config.getBoolean(ConfigPath.GENERAL_CHAT_FORMATTING)) {
            registerEvents(new ChatFormatting());
        }

        /* Protect glass walls from tnt explosion */
        nms.registerTntWhitelist(
                (float) config.getDouble(ConfigPath.GENERAL_TNT_PROTECTION_END_STONE_BLAST),
                (float) config.getDouble(ConfigPath.GENERAL_TNT_PROTECTION_GLASS_BLAST)
        );

        /* Prevent issues on reload */
        for (Player p : Bukkit.getOnlinePlayers()) {
            p.kickPlayer("BedWars1058 was RELOADED! (do not reload plugins)");
        }

        /* Load sounds configuration */
        Sounds.init();

        /* Initialize shop */
        shop = new ShopManager();

        //Leave this code at the end of the enable method
        for (Language l : Language.getLanguages()) {
            l.setupUnSetCategories();
            Language.addDefaultMessagesCommandItems(l);
        }

        LevelsConfig.init();

        /* Load Money Configuration */
        MoneyConfig.init();

        // bStats metrics
        MetricsManager.initService(this);

        if (Bukkit.getPluginManager().getPlugin("VipFeatures") != null) {
            try {
                IVipFeatures vf = Bukkit.getServicesManager().getRegistration(IVipFeatures.class).getProvider();
                vf.registerMiniGame(new VipFeatures(this));
                registerEvents(new VipListeners(vf));
                out.log(java.util.logging.Level.INFO, "Hook into VipFeatures support.");
            } catch (Exception e) {
                out.warning("Could not load support for VipFeatures.");
            } catch (MiniGameAlreadyRegistered miniGameAlreadyRegistered) {
                miniGameAlreadyRegistered.printStackTrace();
            }
        }

        Bukkit.getScheduler().runTaskLater(this,
                () -> out.info("This server is running in " + getServerType() + " with auto-scale " + autoscale),
                100L
        );

        // Initialize team upgrades
        com.andrei1058.bedwars.upgrades.UpgradesManager.init();

        // Initialize external tab/sidebar appearance config (tab.yml + ce.yml)
        com.andrei1058.bedwars.sidebar.ExternalTextConfig.init(this);

        // Initialize sidebar manager
        if (SidebarService.init(this)) {
            out.info("Initializing SidebarLib by andrei1058");
        } else {
            this.getLogger().severe("SidebarLib（andrei1058）不支持当前服务器版本");
            Bukkit.getPluginManager().disablePlugin(this);
            return;
        }

        // Halloween Special
        HalloweenSpecial.init();

        // TNT Spoil Feature
        SpoilPlayerTNTFeature.init();

        // Warn user if current server version support is deprecated
        this.performDeprecationCheck();
    }

    /**
     * Try loading custom adapter support.
     *
     * @return true when custom adapter was registered.
     */
    private boolean handleWorldAdapter() {
        Plugin swmPlugin = Bukkit.getPluginManager().getPlugin("SlimeWorldManager");

        if (null == swmPlugin) {
            return false;
        }
        PluginDescriptionFile pluginDescription = swmPlugin.getDescription();
        if (null == pluginDescription) {
            return false;
        }

        String[] versionString = pluginDescription.getVersion().split("\\.");


        try {
            int major = Integer.parseInt(versionString[0]);
            int minor = Integer.parseInt(versionString[1]);
            int release = versionString.length > 2 ? Integer.parseInt(versionString[2]) : 0;

            String adapterPath;
            if (major == 2 && minor == 2 && release == 1) {
                adapterPath = "com.andrei1058.bedwars.arena.mapreset.slime.SlimeAdapter";
            } else if (major == 2 && minor == 8 && release == 0) {
                adapterPath = "com.andrei1058.bedwars.arena.mapreset.slime.AdvancedSlimeAdapter";
            } else if (major > 2 || major == 2 && minor >= 10) {
                adapterPath = "com.andrei1058.bedwars.arena.mapreset.slime.SlimePaperAdapter";
            } else {
                return false;
            }

            Constructor<?> constructor = Class.forName(adapterPath).getConstructor(Plugin.class);
            getLogger().info("正在加载恢复适配器: " + adapterPath + " ...");

            RestoreAdapter candidate = (RestoreAdapter) constructor.newInstance(this);
            api.setRestoreAdapter(candidate);
            getLogger().info("已接入 " + candidate.getDisplayName() + " 作为恢复适配器。");
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            this.getLogger().info("出现问题！改用内置重置适配器...");
        }
        return false;
    }

    private void registerDelayedCommands() {
        if (!nms.isBukkitCommandRegistered("shout")) {
            nms.registerCommand("shout", new ShoutCommand("shout"));
        }
        nms.registerCommand("rejoin", new RejoinCommand("rejoin"));
        if (!(nms.isBukkitCommandRegistered("leave") && getServerType() == ServerType.BUNGEE)) {
            nms.registerCommand("leave", new LeaveCommand("leave"));
        }
        if (getServerType() != ServerType.BUNGEE && config.getBoolean(ConfigPath.GENERAL_ENABLE_PARTY_CMD)) {
            Bukkit.getLogger().info("正在注册 /party 指令..");
            nms.registerCommand("party", new PartyCommand("party"));
        }
    }

    public void onDisable() {
        shuttingDown = true;
        if (!serverSoftwareSupport) return;
        if (getServerType() == ServerType.BUNGEE) {
            ArenaSocket.disable();
        }
        for (IArena a : new LinkedList<>(Arena.getArenas())) {
            try {
                a.disable();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }

    }

    private void loadArenasAndSigns() {

        api.getRestoreAdapter().convertWorlds();

        File dir = new File(plugin.getDataFolder(), "/Arenas");
        if (dir.exists()) {
            List<File> files = new ArrayList<>();
            File[] fls = dir.listFiles();
            for (File fl : Objects.requireNonNull(fls)) {
                if (fl.isFile()) {
                    if (fl.getName().endsWith(".yml")) {
                        files.add(fl);
                    }
                }
            }

            if (serverType == ServerType.BUNGEE && !autoscale) {
                if (files.isEmpty()) {
                    this.getLogger().log(java.util.logging.Level.WARNING, "Could not find any arena!");
                    return;
                }
                Random r = new Random();
                int x = r.nextInt(files.size());
                String name = files.get(x).getName().replace(".yml", "");
                new Arena(name, null);
            } else {
                for (File file : files) {
                    new Arena(file.getName().replace(".yml", ""), null);
                }
            }
        }
    }

    public static void registerEvents(Listener... listeners) {
        Arrays.stream(listeners).forEach(l -> plugin.getServer().getPluginManager().registerEvents(l, plugin));
    }

    public static void setDebug(boolean value) {
        debug = value;
    }

    public static void setServerType(ServerType serverType) {
        BedWars.serverType = serverType;
        if (serverType == ServerType.BUNGEE) autoscale = true;
    }

    public static void setAutoscale(boolean autoscale) {
        BedWars.autoscale = autoscale;
    }

    public static void debug(String message) {
        if (debug) {
            plugin.getLogger().info("调试: " + message);
        }
    }

    public static String getForCurrentVersion(String v18, String v12, String v13) {
        switch (getServerVersion()) {
            case "v1_8_R3":
                return v18;
            case "v1_12_R1":
                return v12;
        }
        return v13;
    }

    public static ServerType getServerType() {
        return serverType;
    }

    public static Party getParty() {
        return party;
    }

    public static Chat getChatSupport() {
        return chat;
    }

    /**
     * Get current levels manager.
     */
    public static Level getLevelSupport() {
        return level;
    }

    /**
     * Set the levels manager.
     * You can use this to add your own levels manager just implement
     * the Level interface so the plugin will be able to display
     * the level internally.
     */

    public static void setLevelAdapter(Level levelsManager) {
        if (levelsManager instanceof InternalLevel) {
            if (LevelListeners.instance == null) {
                Bukkit.getPluginManager().registerEvents(new LevelListeners(), BedWars.plugin);
            }
        } else {
            if (LevelListeners.instance != null) {
                PlayerJoinEvent.getHandlerList().unregister(LevelListeners.instance);
                PlayerQuitEvent.getHandlerList().unregister(LevelListeners.instance);
                LevelListeners.instance = null;
            }
        }
        level = levelsManager;
    }

    public static Economy getEconomy() {
        return economy;
    }

    public static ConfigManager getGeneratorsCfg() {
        return generators;
    }

    public static void setLobbyWorld(String lobbyWorld) {
        BedWars.lobbyWorld = lobbyWorld;
    }

    /**
     * Get the server version
     * Ex: v1_8_R3
     *
     * @since v0.6.5beta
     */
    public static String getServerVersion() {
        return version;
    }

    /**
     * Detect the version identifier used for the version support adapters.
     * <p>
     * Legacy CraftBukkit/Spigot runtimes still ship the NMS revision in the
     * server class package (org.bukkit.craftbukkit.v1_XX_RX.CraftServer).
     * Modern Paper runtimes (1.21.x) dropped the revision from the package
     * name, so the identifier is rebuilt from {@code Bukkit#getBukkitVersion()}
     * instead (e.g. "1.21.11-R0.1-SNAPSHOT" -> "v1_21_11").
     */
    private static String detectServerVersionIdentifier() {
        String className = Bukkit.getServer().getClass().getName();
        String[] split = className.split("\\.");
        if (split.length > 3 && split[3].startsWith("v1_")) {
            return split[3];
        }
        String bukkitVersion = Bukkit.getBukkitVersion();
        String mcVersion = (bukkitVersion == null || bukkitVersion.isEmpty()) ? "1_21_11" : bukkitVersion.split("-")[0].replace('.', '_');
        return "v" + mcVersion;
    }

    private static final Map<String, String> ENCHANTMENT_ALIASES = new HashMap<>();

    static {
        // Minecraft 1.20.5+ renamed several Bukkit enchantment constants.
        // Old names stored in configs are mapped to the new ones when the old ones no longer resolve.
        ENCHANTMENT_ALIASES.put("ARROW_DAMAGE", "POWER");
        ENCHANTMENT_ALIASES.put("ARROW_FIRE", "FLAME");
        ENCHANTMENT_ALIASES.put("ARROW_INFINITE", "INFINITY");
        ENCHANTMENT_ALIASES.put("ARROW_KNOCKBACK", "PUNCH");
        ENCHANTMENT_ALIASES.put("DURABILITY", "UNBREAKING");
        ENCHANTMENT_ALIASES.put("DAMAGE_ALL", "SHARPNESS");
        ENCHANTMENT_ALIASES.put("DAMAGE_ARTHROPODS", "BANE_OF_ARTHROPODS");
        ENCHANTMENT_ALIASES.put("DAMAGE_UNDEAD", "SMITE");
        ENCHANTMENT_ALIASES.put("DIG_SPEED", "EFFICIENCY");
        ENCHANTMENT_ALIASES.put("LOOT_BONUS_BLOCKS", "FORTUNE");
        ENCHANTMENT_ALIASES.put("LOOT_BONUS_MOBS", "LOOTING");
        ENCHANTMENT_ALIASES.put("LUCK", "LUCK_OF_THE_SEA");
        ENCHANTMENT_ALIASES.put("OXYGEN", "RESPIRATION");
        ENCHANTMENT_ALIASES.put("PROTECTION_ENVIRONMENTAL", "PROTECTION");
        ENCHANTMENT_ALIASES.put("PROTECTION_EXPLOSIONS", "BLAST_PROTECTION");
        ENCHANTMENT_ALIASES.put("PROTECTION_FALL", "FEATHER_FALLING");
        ENCHANTMENT_ALIASES.put("PROTECTION_FIRE", "FIRE_PROTECTION");
        ENCHANTMENT_ALIASES.put("PROTECTION_PROJECTILE", "PROJECTILE_PROTECTION");
        ENCHANTMENT_ALIASES.put("WATER_WORKER", "AQUA_AFFINITY");
    }

    /**
     * Resolve an enchantment from its configured name.
     * <p>
     * Tries {@link Enchantment#getByName(String)} first and falls back to the
     * pre-1.20.5 name mapping so configs using legacy names (DAMAGE_ALL,
     * PROTECTION_ENVIRONMENTAL, ARROW_DAMAGE, ...) keep working on modern servers.
     *
     * @return the resolved enchantment, or {@code null} when the name is unknown.
     */
    public static Enchantment getEnchantmentByName(String name) {
        if (name == null || name.isEmpty()) {
            return null;
        }
        String key = name.toUpperCase();
        Enchantment enchantment = Enchantment.getByName(key);
        if (enchantment != null) {
            return enchantment;
        }
        // Legacy config name (pre-1.20.5) mapped to the modern name.
        String alias = ENCHANTMENT_ALIASES.get(key);
        if (alias != null) {
            enchantment = Enchantment.getByName(alias);
            if (enchantment != null) {
                return enchantment;
            }
        }
        // Modern config name running on a legacy server: map back to the old constant.
        for (Map.Entry<String, String> entry : ENCHANTMENT_ALIASES.entrySet()) {
            if (entry.getValue().equals(key)) {
                enchantment = Enchantment.getByName(entry.getKey());
                if (enchantment != null) {
                    return enchantment;
                }
            }
        }
        return null;
    }

    public static String getLobbyWorld() {
        return lobbyWorld;
    }

    /**
     * Get remote database.
     */
    public static Database getRemoteDatabase() {
        return remoteDatabase;
    }

    public static StatsManager getStatsManager() {
        return statsManager;
    }

    public static com.andrei1058.bedwars.api.BedWars getAPI() {
        return api;
    }

    public static boolean isShuttingDown() {
        return shuttingDown;
    }

    public static void setParty(Party party) {
        BedWars.party = party;
    }

    public void performDeprecationCheck() {
        Bukkit.getScheduler().runTaskAsynchronously(this, () -> {
            if (Arrays.stream(nms.getClass().getAnnotations()).anyMatch(annotation -> annotation instanceof Deprecated)) {
                this.getLogger().warning("对 " + getServerVersion() + " 的支持将被移除。 " +
                        "请考虑将服务器升级到更新的 Minecraft 版本。");
            }
        });
    }

    @Override
    public ChunkGenerator getDefaultWorldGenerator(String worldName, String id) {
        return new VoidChunkGenerator();
    }
}
